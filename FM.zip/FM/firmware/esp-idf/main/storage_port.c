#include "storage_port.h"

#include "authorization.h"
#include "event_log.h"

#include "esp_log.h"
#include "nvs.h"
#include "nvs_flash.h"

#include <stdlib.h>

static const char *TAG = "storage";
static uint32_t s_boot;

static size_t export_auth0(uint8_t *dst, size_t cap) {
    return auth_export_half(0, dst, cap);
}

static size_t export_auth1(uint8_t *dst, size_t cap) {
    return auth_export_half(1, dst, cap);
}

static void load_blob(nvs_handle_t handle, const char *key, bool (*import)(const uint8_t *, size_t), size_t size) {
    uint8_t *buffer = malloc(size);
    size_t length = size;
    esp_err_t err;

    if (buffer == NULL) {
        ESP_LOGE(TAG, "no memory for %s", key);
        return;
    }
    err = nvs_get_blob(handle, key, buffer, &length);
    if (err == ESP_OK) {
        if (!import(buffer, length)) {
            ESP_LOGW(TAG, "ignored unreadable %s", key);
        }
    } else if (err != ESP_ERR_NVS_NOT_FOUND) {
        ESP_LOGW(TAG, "read %s failed: %s", key, esp_err_to_name(err));
    }
    free(buffer);
}

static void save_blob(const char *key, size_t (*export_fn)(uint8_t *, size_t), size_t size) {
    nvs_handle_t handle;
    uint8_t *buffer;
    size_t written;
    esp_err_t err;

    buffer = malloc(size);
    if (buffer == NULL) {
        ESP_LOGE(TAG, "no memory to save %s", key);
        return;
    }
    written = export_fn(buffer, size);
    if (written != size) {
        ESP_LOGE(TAG, "export %s failed", key);
        free(buffer);
        return;
    }
    err = nvs_open("door", NVS_READWRITE, &handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "open failed: %s", esp_err_to_name(err));
        free(buffer);
        return;
    }
    err = nvs_set_blob(handle, key, buffer, written);
    if (err == ESP_OK) {
        err = nvs_commit(handle);
    }
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "save %s failed: %s", key, esp_err_to_name(err));
    }
    nvs_close(handle);
    free(buffer);
}

void storage_init(void) {
    nvs_handle_t handle;
    esp_err_t err = nvs_flash_init();

    auth_init();
    event_log_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "NVS reset");
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK(err);

    err = nvs_open("door", NVS_READWRITE, &handle);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "namespace open failed: %s", esp_err_to_name(err));
        return;
    }
    load_blob(handle, "auth0", auth_import_half, AUTH_BLOB_SIZE);
    load_blob(handle, "auth1", auth_import_half, AUTH_BLOB_SIZE);
    load_blob(handle, "events", event_log_import, EVENT_BLOB_SIZE);
    s_boot = 0u;
    if (nvs_get_u32(handle, "boot", &s_boot) != ESP_OK) {
        s_boot = 0u;
    }
    s_boot++;
    if (nvs_set_u32(handle, "boot", s_boot) == ESP_OK) {
        nvs_commit(handle);
    }
    nvs_close(handle);
    event_log_set_boot(s_boot);
}

void storage_save_users(void) {
    save_blob("auth0", export_auth0, AUTH_BLOB_SIZE);
    save_blob("auth1", export_auth1, AUTH_BLOB_SIZE);
}

void storage_save_events(void) {
    save_blob("events", event_log_export, EVENT_BLOB_SIZE);
}

uint32_t storage_boot_count(void) {
    return s_boot;
}
