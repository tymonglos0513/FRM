#pragma once

#include "access_sm.h"

#include <stdbool.h>
#include <stdint.h>

void door_request_scan(void);
void door_request_test_pulse(void);

acc_state_t door_state(void);
bool door_lock_output(void);
bool door_tamper(void);
bool door_maintenance(void);
bool door_closed(void);
bool door_supply_failed(void);
uint32_t door_supply_mv(void);
uint8_t door_fail_count(void);
