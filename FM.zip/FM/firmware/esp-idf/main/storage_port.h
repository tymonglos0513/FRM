#pragma once

#include <stdint.h>

void storage_init(void);
void storage_save_users(void);
void storage_save_events(void);
uint32_t storage_boot_count(void);
