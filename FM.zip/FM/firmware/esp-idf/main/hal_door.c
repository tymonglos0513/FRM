#include "hal_door.h"

#include "board.h"

#include "driver/gpio.h"
#include "esp_adc/adc_oneshot.h"
#include "esp_log.h"
#include "esp_task_wdt.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "hal";

static adc_oneshot_unit_handle_t s_adc;
static bool s_adc_ok;
static bool s_seen_good;
static int s_low_count;
static int s_supply_mv;
static int64_t s_last_sample_us;
static volatile bool s_lock_requested;
static volatile bool s_cut_off;
static volatile uint32_t s_lock_on_ms;

static void lock_supervisor(void *arg) {
    bool watched = esp_task_wdt_add(NULL) == ESP_OK;
    (void)arg;
    for (;;) {
        if (watched) {
            esp_task_wdt_reset();
        }
        if (gpio_get_level(PIN_LOCK) == 1) {
            uint32_t age_ms = hal_millis() - s_lock_on_ms;
            if (!s_lock_requested || age_ms > LOCK_HARD_MAX_MS) {
                gpio_set_level(PIN_LOCK, 0);
                s_lock_requested = false;
                s_cut_off = true;
                ESP_LOGE(TAG, "lock output forced off");
            }
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

static void configure_lock_off(void) {
    gpio_config_t cfg = {
        .pin_bit_mask = 1ULL << PIN_LOCK,
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_ENABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config(&cfg);
    gpio_set_level(PIN_LOCK, 0);
}

void hal_init(void) {
    gpio_config_t outputs = {
        .pin_bit_mask = (1ULL << PIN_GREEN) | (1ULL << PIN_RED) | (1ULL << PIN_BUZZER),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    gpio_config_t inputs = {
        .pin_bit_mask = (1ULL << PIN_DOOR) | (1ULL << PIN_EXIT) | (1ULL << PIN_SCAN) | (1ULL << PIN_TAMPER) |
                        (1ULL << PIN_MAINT),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };
    adc_oneshot_unit_init_cfg_t unit_cfg = {.unit_id = ADC_UNIT_1};
    adc_oneshot_chan_cfg_t chan_cfg = {
        .bitwidth = ADC_BITWIDTH_12,
#if defined(ADC_ATTEN_DB_12)
        .atten = ADC_ATTEN_DB_12,
#else
        .atten = ADC_ATTEN_DB_11,
#endif
    };

    configure_lock_off();
    gpio_config(&outputs);
    gpio_set_level(PIN_GREEN, 0);
    gpio_set_level(PIN_RED, 0);
    gpio_set_level(PIN_BUZZER, 0);
    gpio_config(&inputs);

    if (adc_oneshot_new_unit(&unit_cfg, &s_adc) == ESP_OK &&
        adc_oneshot_config_channel(s_adc, ADC_CHANNEL_0, &chan_cfg) == ESP_OK) {
        s_adc_ok = true;
    } else {
        ESP_LOGE(TAG, "12V sense ADC unavailable; brownout hint disabled");
    }

    xTaskCreate(lock_supervisor, "locksup", 3072, NULL, 12, NULL);
}

uint32_t hal_millis(void) {
    return (uint32_t)(esp_timer_get_time() / 1000LL);
}

void hal_lock_set(bool on) {
    if (!on) {
        s_cut_off = false;
        s_lock_requested = false;
        gpio_set_level(PIN_LOCK, 0);
        return;
    }
    if (s_cut_off) {
        gpio_set_level(PIN_LOCK, 0);
        s_lock_requested = false;
        return;
    }
    if (!s_lock_requested) {
        s_lock_on_ms = hal_millis();
    }
    s_lock_requested = true;
    gpio_set_level(PIN_LOCK, 1);
}

void hal_set_indicators(bool green, bool red, bool buzzer) {
    gpio_set_level(PIN_GREEN, green ? 1 : 0);
    gpio_set_level(PIN_RED, red ? 1 : 0);
    gpio_set_level(PIN_BUZZER, buzzer ? 1 : 0);
}

void hal_read_contacts(hal_contacts_t *contacts) {
    contacts->door_closed = gpio_get_level(PIN_DOOR) == 0;
    contacts->exit_down = gpio_get_level(PIN_EXIT) == 0;
    contacts->scan_down = gpio_get_level(PIN_SCAN) == 0;
    contacts->tamper = gpio_get_level(PIN_TAMPER) != 0;
    contacts->maintenance = gpio_get_level(PIN_MAINT) == 0;
}

static void sample_supply(void) {
    int raw = 0;
    int mv_pin;
    int64_t now;

    if (!s_adc_ok) {
        return;
    }
    now = esp_timer_get_time();
    if (s_last_sample_us != 0 && (now - s_last_sample_us) < 50000LL) {
        return;
    }
    s_last_sample_us = now;
    if (adc_oneshot_read(s_adc, ADC_CHANNEL_0, &raw) != ESP_OK) {
        return;
    }
    mv_pin = (raw * 3100) / 4095;
    s_supply_mv = (mv_pin * (SENSE_TOP_OHMS + SENSE_BOT_OHMS)) / SENSE_BOT_OHMS;
    if (s_supply_mv >= SENSE_RECOVER_MV) {
        s_seen_good = true;
        s_low_count = 0;
    } else if (s_supply_mv < SENSE_BROWNOUT_MV && s_seen_good) {
        if (s_low_count < 100) {
            s_low_count++;
        }
    }
}

bool hal_supply_failed(void) {
    sample_supply();
    return s_seen_good && s_low_count >= 10;
}

uint32_t hal_supply_mv(void) {
    return (uint32_t)s_supply_mv;
}
