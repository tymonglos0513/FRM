#pragma once

#include "access_sm.h"

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    acc_face_kind_t face;
    bool cancel;
    uint16_t slot;
    uint8_t code;
} fm_result_t;

void fm225_port_start(void);
bool fm225_request_verify(void);
bool fm225_request_enroll(const char *name);
bool fm225_request_delete(uint16_t slot);
bool fm225_request_delete_all(void);
bool fm225_poll_result(fm_result_t *out);
const char *fm225_version(void);
