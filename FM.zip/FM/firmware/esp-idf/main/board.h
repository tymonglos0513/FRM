#pragma once

#include "driver/gpio.h"

/* ESP32-S3-DevKitC-1-N8R8 wiring. These pins avoid the strapping pins
 * (GPIO0, GPIO3, GPIO45, GPIO46), the USB pins (GPIO19, GPIO20), the
 * module flash pins (GPIO26-GPIO32) and the octal-PSRAM pins (GPIO33-GPIO37). */

#define PIN_SENSE GPIO_NUM_1
#define PIN_LOCK GPIO_NUM_4
#define PIN_DOOR GPIO_NUM_5
#define PIN_EXIT GPIO_NUM_6
#define PIN_SCAN GPIO_NUM_7
#define PIN_GREEN GPIO_NUM_8
#define PIN_RED GPIO_NUM_9
#define PIN_BUZZER GPIO_NUM_10
#define PIN_TAMPER GPIO_NUM_11
#define PIN_MAINT GPIO_NUM_12
#define PIN_UART_TX GPIO_NUM_17
#define PIN_UART_RX GPIO_NUM_18

#define LOCK_HARD_MAX_MS 10000u

/* Divider on PIN_SENSE: 100k from +12V, 22k to ground.
 * The conversion is uncalibrated and is only a brownout hint. */
#define SENSE_TOP_OHMS 100
#define SENSE_BOT_OHMS 22
#define SENSE_BROWNOUT_MV 10500
#define SENSE_RECOVER_MV 11500
