#include "authorization.h"
#include "door_app.h"
#include "storage_port.h"
#include "event_log.h"
#include "fm225_port.h"
#include "hal_door.h"

#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *TAG = "console";

static int split_args(char *line, char **argv, int max_args) {
    int argc = 0;
    char *cursor = line;
    while (*cursor != '\0' && argc < max_args) {
        while (*cursor == ' ') {
            cursor++;
        }
        if (*cursor == '\0') {
            break;
        }
        argv[argc++] = cursor;
        while (*cursor != '\0' && *cursor != ' ') {
            cursor++;
        }
        if (*cursor != '\0') {
            *cursor = '\0';
            cursor++;
        }
    }
    return argc;
}

static bool parse_slot(const char *text, uint16_t *slot) {
    char *end = NULL;
    long value = strtol(text, &end, 10);
    if (end == text || *end != '\0' || value < 0 || value > 99) {
        return false;
    }
    *slot = (uint16_t)value;
    return true;
}

static bool maintenance_held(void) {
    hal_contacts_t contacts;
    hal_read_contacts(&contacts);
    return contacts.maintenance && !contacts.tamper;
}

static void print_help(void) {
    printf("status\n");
    printf("users\n");
    printf("log\n");
    printf("scan\n");
    printf("allow <slot> <name>      maintenance key required\n");
    printf("revoke <slot>            maintenance key required\n");
    printf("enroll <name>            maintenance key required\n");
    printf("delete <slot>            maintenance key required\n");
    printf("deleteall CONFIRM        maintenance key required\n");
    printf("testpulse                maintenance key required, dummy load only\n");
}

static void print_status(void) {
    printf("state %s lock %s door %s tamper %s maintenance %s supply %s %lumV fails %u version %s users %u\n",
           acc_state_name(door_state()), door_lock_output() ? "on" : "off", door_closed() ? "closed" : "open",
           door_tamper() ? "open" : "closed", door_maintenance() ? "on" : "off",
           door_supply_failed() ? "low" : "ok", (unsigned long)door_supply_mv(), door_fail_count(), fm225_version(),
           (unsigned)auth_used_count());
}

static void print_users(void) {
    uint16_t slot;
    for (slot = 0u; slot < AUTH_CAPACITY; slot++) {
        auth_user_t user;
        if (!auth_get(slot, &user)) {
            continue;
        }
        printf("slot %u %s %s\n", slot, user.enabled ? "allowed" : "revoked", user.name);
    }
}

static void print_log(void) {
    size_t i;
    size_t count = event_log_count();
    if (count > 12u) {
        count = 12u;
    }
    for (i = 0u; i < count; i++) {
        door_event_t event;
        if (!event_log_newest(i, &event)) {
            break;
        }
        printf("boot %lu +%lums %s slot %d code %u\n", (unsigned long)event.boot, (unsigned long)event.uptime_ms,
               event_type_name(event.type), event.slot, event.code);
    }
}

static void handle_line(char *line) {
    char *argv[4];
    int argc = split_args(line, argv, 4);
    uint16_t slot = 0u;
    if (argc == 0) {
        return;
    }
    if (strcmp(argv[0], "help") == 0) {
        print_help();
    } else if (strcmp(argv[0], "status") == 0) {
        print_status();
    } else if (strcmp(argv[0], "users") == 0) {
        print_users();
    } else if (strcmp(argv[0], "log") == 0) {
        print_log();
    } else if (strcmp(argv[0], "scan") == 0) {
        door_request_scan();
        printf("scan requested\n");
    } else if (strcmp(argv[0], "testpulse") == 0) {
        if (!maintenance_held()) {
            printf("turn the maintenance key and close the enclosure\n");
            return;
        }
        door_request_test_pulse();
        printf("test pulse requested\n");
    } else if (strcmp(argv[0], "allow") == 0 && argc == 3 && parse_slot(argv[1], &slot)) {
        if (!maintenance_held()) {
            printf("turn the maintenance key and close the enclosure\n");
            return;
        }
        if (!auth_allow_always(slot, argv[2])) {
            printf("name rejected\n");
            return;
        }
        storage_save_users();
        event_log_add(DOOR_EVT_ENROLL, (int16_t)slot, 1u, hal_millis());
        storage_save_events();
        printf("slot %u allowed\n", slot);
    } else if (strcmp(argv[0], "revoke") == 0 && argc == 2 && parse_slot(argv[1], &slot)) {
        if (!maintenance_held()) {
            printf("turn the maintenance key and close the enclosure\n");
            return;
        }
        if (!auth_set_enabled(slot, false)) {
            printf("unknown slot\n");
            return;
        }
        storage_save_users();
        event_log_add(DOOR_EVT_REVOKE, (int16_t)slot, 0u, hal_millis());
        storage_save_events();
        printf("slot %u revoked\n", slot);
    } else if (strcmp(argv[0], "enroll") == 0 && argc == 2) {
        if (!maintenance_held()) {
            printf("turn the maintenance key and close the enclosure\n");
            return;
        }
        if (!fm225_request_enroll(argv[1])) {
            printf("module busy\n");
            return;
        }
        printf("enrollment started\n");
    } else if (strcmp(argv[0], "delete") == 0 && argc == 2 && parse_slot(argv[1], &slot)) {
        if (!maintenance_held()) {
            printf("turn the maintenance key and close the enclosure\n");
            return;
        }
        if (!fm225_request_delete(slot)) {
            printf("module busy\n");
            return;
        }
        printf("delete requested\n");
    } else if (strcmp(argv[0], "deleteall") == 0 && argc == 2 && strcmp(argv[1], "CONFIRM") == 0) {
        if (!maintenance_held()) {
            printf("turn the maintenance key and close the enclosure\n");
            return;
        }
        if (!fm225_request_delete_all()) {
            printf("module busy\n");
            return;
        }
        printf("delete all requested\n");
    } else {
        printf("unknown command\n");
        print_help();
    }
}

static void console_task(void *arg) {
    char line[96];
    size_t length = 0u;
    (void)arg;
    print_help();
    for (;;) {
        int ch = getchar();
        if (ch < 0) {
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        if (ch == '\r' || ch == '\n') {
            if (length > 0u) {
                line[length] = '\0';
                handle_line(line);
                length = 0u;
            }
            continue;
        }
        if (length + 1u < sizeof line) {
            line[length++] = (char)ch;
        }
    }
}

void console_start(void) {
    xTaskCreate(console_task, "console", 4096, NULL, 3, NULL);
    ESP_LOGI(TAG, "maintenance console on USB");
}
