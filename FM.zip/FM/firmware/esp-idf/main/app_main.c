#include "access_sm.h"
#include "data_lock.h"
#include "debounce.h"
#include "door_app.h"
#include "event_log.h"
#include "fm225_port.h"
#include "hal_door.h"
#include "storage_port.h"

#include "console_task.h"

#include "esp_log.h"

#include <string.h>
#include "esp_task_wdt.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

static const char *TAG = "door";

static volatile bool s_scan_req;
static volatile bool s_pulse_req;
static volatile acc_state_t s_state = ACC_LOCKED;
static volatile bool s_lock_output;
static volatile bool s_tamper;
static volatile bool s_maintenance;
static volatile bool s_door_closed = true;
static volatile bool s_supply_failed;
static volatile uint32_t s_supply_mv;
static volatile uint8_t s_fail_count;

void door_request_scan(void) {
    s_scan_req = true;
}

void door_request_test_pulse(void) {
    s_pulse_req = true;
}

acc_state_t door_state(void) {
    return s_state;
}
bool door_lock_output(void) {
    return s_lock_output;
}
bool door_tamper(void) {
    return s_tamper;
}
bool door_maintenance(void) {
    return s_maintenance;
}
bool door_closed(void) {
    return s_door_closed;
}
bool door_supply_failed(void) {
    return s_supply_failed;
}
uint32_t door_supply_mv(void) {
    return s_supply_mv;
}
uint8_t door_fail_count(void) {
    return s_fail_count;
}

static void note_event(bool flag, uint16_t type, int16_t slot, uint16_t code, uint32_t now, bool *dirty) {
    if (!flag) {
        return;
    }
    event_log_add(type, slot, code, now);
    *dirty = true;
}

static void access_task(void *arg) {
    acc_t door;
    debounce_t door_db;
    debounce_t exit_db;
    debounce_t scan_db;
    debounce_t tamper_db;
    debounce_t maint_db;
    bool watched = esp_task_wdt_add(NULL) == ESP_OK;
    bool prev_brownout = false;
    (void)arg;

    debounce_init(&door_db);
    debounce_init(&exit_db);
    debounce_init(&scan_db);
    debounce_init(&tamper_db);
    debounce_init(&maint_db);
    acc_init(&door);

    for (;;) {
        hal_contacts_t contacts;
        acc_input_t input;
        fm_result_t result;
        bool rose = false;
        bool fell = false;
        bool dirty = false;
        bool maintenance;
        uint32_t now = hal_millis();
        uint16_t exit_code = 0u;

        memset(&input, 0, sizeof input);
        hal_read_contacts(&contacts);
        input.door_closed = debounce_update(&door_db, contacts.door_closed, now, 50u, &rose, &fell);
        debounce_update(&exit_db, contacts.exit_down, now, 30u, &rose, &fell);
        input.exit_edge = rose;
        debounce_update(&scan_db, contacts.scan_down, now, 30u, &rose, &fell);
        input.scan_edge = rose;
        input.tamper = debounce_update(&tamper_db, contacts.tamper, now, 50u, &rose, &fell);
        maintenance = debounce_update(&maint_db, contacts.maintenance, now, 50u, &rose, &fell);
        input.supply_failed = hal_supply_failed();

        if (s_scan_req) {
            s_scan_req = false;
            input.scan_edge = true;
        }
        if (s_pulse_req) {
            s_pulse_req = false;
            if (maintenance && !input.tamper) {
                input.exit_edge = true;
                exit_code = 2u;
            }
        }
        if (fm225_poll_result(&result)) {
            if (result.cancel) {
                input.cancel_scan = true;
            } else {
                input.face = result.face;
                input.face_slot = result.slot;
                input.face_code = result.code;
            }
        }

        acc_step(&door, &input, now);
        if (door.issue_scan && !fm225_request_verify()) {
            input.scan_edge = false;
            input.cancel_scan = true;
            input.face = ACC_FACE_NONE;
            acc_step(&door, &input, now);
            note_event(true, DOOR_EVT_FAULT, -1, 2u, now, &dirty);
        }

        hal_lock_set(door.lock_output);
        hal_set_indicators(door.green, door.red, door.buzzer);

        s_state = door.state;
        s_lock_output = door.lock_output;
        s_tamper = input.tamper;
        s_maintenance = maintenance;
        s_door_closed = input.door_closed;
        s_supply_failed = input.supply_failed;
        s_supply_mv = hal_supply_mv();
        s_fail_count = door.fail_count;

        if (input.supply_failed && !prev_brownout) {
            note_event(true, DOOR_EVT_BROWNOUT, -1, 0u, now, &dirty);
        }
        prev_brownout = input.supply_failed;
        note_event(door.evt_granted, DOOR_EVT_GRANTED, (int16_t)door.last_slot, 0u, now, &dirty);
        note_event(door.evt_denied && !door.evt_unmatched, DOOR_EVT_DENIED, (int16_t)door.last_slot, input.face_code, now,
                   &dirty);
        note_event(door.evt_unmatched, DOOR_EVT_UNMATCHED, -1, input.face_code, now, &dirty);
        note_event(door.evt_exit, DOOR_EVT_EXIT, -1, exit_code, now, &dirty);
        note_event(door.evt_forced, DOOR_EVT_FORCED, -1, 0u, now, &dirty);
        note_event(door.evt_held, DOOR_EVT_HELD, -1, 0u, now, &dirty);
        note_event(door.evt_tamper, DOOR_EVT_TAMPER, -1, 0u, now, &dirty);
        note_event(door.evt_lockout, DOOR_EVT_LOCKOUT, -1, door.fail_count, now, &dirty);
        note_event(door.evt_timeout, DOOR_EVT_SCAN_TIMEOUT, -1, 0u, now, &dirty);
        note_event(door.evt_stale, DOOR_EVT_STALE, (int16_t)door.last_slot, 0u, now, &dirty);
        if (dirty) {
            storage_save_events();
        }
        if (watched) {
            esp_task_wdt_reset();
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

void app_main(void) {
    hal_init();
    data_lock_init();
    storage_init();
    event_log_add(DOOR_EVT_BOOT, -1, 0u, hal_millis());
    storage_save_events();
    fm225_port_start();
    xTaskCreate(access_task, "access", 8192, NULL, 8, NULL);
    console_start();
    ESP_LOGI(TAG, "boot %lu, lock held off, %u local users", (unsigned long)storage_boot_count(),
             (unsigned)auth_used_count());
}
