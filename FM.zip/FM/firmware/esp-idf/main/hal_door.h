#pragma once

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    bool door_closed;
    bool exit_down;
    bool scan_down;
    bool tamper;
    bool maintenance;
} hal_contacts_t;

void hal_init(void);
uint32_t hal_millis(void);
void hal_lock_set(bool on);
void hal_set_indicators(bool green, bool red, bool buzzer);
void hal_read_contacts(hal_contacts_t *contacts);
bool hal_supply_failed(void);
uint32_t hal_supply_mv(void);
