#include "fm225_port.h"

#include "authorization.h"
#include "board.h"
#include "door_logic.h"
#include "event_log.h"
#include "fm225_protocol.h"
#include "hal_door.h"
#include "storage_port.h"

#include "driver/uart.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"

#include <stdio.h>
#include <string.h>

static const char *TAG = "fm225";
static const uart_port_t FM_UART = UART_NUM_1;

typedef enum { CMD_VERIFY = 1, CMD_ENROLL, CMD_DELETE, CMD_DELETE_ALL } cmd_type_t;

typedef struct {
    cmd_type_t type;
    char name[32];
    uint16_t slot;
} fm_cmd_t;

static QueueHandle_t s_cmds;
static QueueHandle_t s_results;
static fm225_parser_t s_parser;
static char s_version[48] = "unknown";
static volatile bool s_busy;

static void post_result(acc_face_kind_t face, uint16_t slot, uint8_t code) {
    fm_result_t result = {.face = face, .slot = slot, .code = code};
    if (xQueueSend(s_results, &result, 0) != pdTRUE) {
        ESP_LOGW(TAG, "dropped recognition result");
    }
}

static void flush_rx(void) {
    uart_flush_input(FM_UART);
    fm225_parser_init(&s_parser);
}

typedef enum { TR_REPLY = 0, TR_FAIL, TR_TIMEOUT } tr_status_t;

static tr_status_t transact(const uint8_t *tx, size_t tx_len, uint8_t expect_cmd, fm225_frame_t *reply,
                            uint32_t timeout_ms) {
    uint32_t start = hal_millis();
    flush_rx();
    if (uart_write_bytes(FM_UART, tx, tx_len) != (int)tx_len) {
        return TR_FAIL;
    }
    while ((uint32_t)(hal_millis() - start) < timeout_ms) {
        uint8_t buf[64];
        int n = uart_read_bytes(FM_UART, buf, sizeof buf, pdMS_TO_TICKS(50));
        int i;
        if (n < 0) {
            return TR_FAIL;
        }
        for (i = 0; i < n; i++) {
            fm_parse_status_t status = fm225_parse_byte(&s_parser, buf[i], reply);
            if (status == FM_PARSE_CHECKSUM || status == FM_PARSE_OVERSIZE) {
                ESP_LOGW(TAG, "bad frame");
                continue;
            }
            if (status != FM_PARSE_FRAME) {
                continue;
            }
            if (fm225_note_is_ready(reply)) {
                return TR_FAIL;
            }
            if (reply->msg == FM225_MSG_NOTE) {
                continue;
            }
            if (reply->msg == FM225_MSG_REPLY) {
                fm225_reply_t decoded;
                if (!fm225_decode_reply(reply, &decoded) || decoded.command != expect_cmd) {
                    return TR_FAIL;
                }
                return TR_REPLY;
            }
        }
    }
    return TR_TIMEOUT;
}

static void remember_version(const fm225_frame_t *frame) {
    fm225_reply_t reply;
    if (!fm225_decode_reply(frame, &reply) || reply.name[0] == '\0') {
        return;
    }
    snprintf(s_version, sizeof s_version, "%s", reply.name);
}

static bool bringup(void) {
    uint8_t tx[16];
    fm225_frame_t rx;
    fm225_reply_t reply;
    size_t n = fm225_build_reset(tx, sizeof tx);
    if (transact(tx, n, FM225_CMD_RESET, &rx, 3000u) != TR_REPLY || !fm225_decode_reply(&rx, &reply) ||
        reply.result != FM225_OK) {
        ESP_LOGW(TAG, "module reset failed");
        return false;
    }
    n = fm225_build_status(tx, sizeof tx);
    if (transact(tx, n, FM225_CMD_GET_STATUS, &rx, 2000u) != TR_REPLY || !fm225_decode_reply(&rx, &reply) ||
        reply.result != FM225_OK) {
        ESP_LOGW(TAG, "module status failed");
        return false;
    }
    n = fm225_build_version(tx, sizeof tx);
    if (transact(tx, n, FM225_CMD_GET_VERSION, &rx, 2000u) == TR_REPLY) {
        remember_version(&rx);
    }
    ESP_LOGI(TAG, "module ready, version %s", s_version);
    return true;
}

static void post_cancel(void) {
    fm_result_t result = {.cancel = true, .face = ACC_FACE_NONE};
    if (xQueueSend(s_results, &result, 0) != pdTRUE) {
        ESP_LOGW(TAG, "dropped scan cancel");
    }
}

static void do_verify(void) {
    uint8_t tx[16];
    fm225_frame_t rx;
    size_t n = fm225_build_verify(tx, sizeof tx);
    uint16_t slot = 0u;
    uint8_t code = FM225_ERR_TIMEOUT;
    acc_face_kind_t face;
    memset(&rx, 0, sizeof rx);
    if (transact(tx, n, FM225_CMD_VERIFY, &rx, 7000u) != TR_REPLY) {
        post_cancel();
        return;
    }
    face = door_classify_verify(&rx, &slot, &code, false, 0u, 0u);
    if (face == ACC_FACE_NONE) {
        post_cancel();
        return;
    }
    post_result(face, slot, code);
}

static void forget_partial(uint16_t slot, bool have_id) {
    uint8_t tx[16];
    fm225_frame_t rx;
    size_t n;
    if (!have_id) {
        return;
    }
    n = fm225_build_delete(slot, tx, sizeof tx);
    (void)transact(tx, n, FM225_CMD_DELETE, &rx, 3000u);
}

static void do_enroll(const char *name) {
    static const uint8_t dirs[] = {FM225_DIR_MIDDLE, FM225_DIR_RIGHT, FM225_DIR_LEFT, FM225_DIR_DOWN, FM225_DIR_UP};
    static const char *labels[] = {"center", "right", "left", "down", "up"};
    bool have_id = false;
    uint16_t slot = 0u;
    size_t i;

    for (i = 0u; i < 5u; i++) {
        hal_contacts_t contacts;
        uint8_t tx[48];
        fm225_frame_t rx;
        fm225_reply_t reply;
        size_t n;
        hal_read_contacts(&contacts);
        if (!door_enrollment_permitted(contacts.maintenance, contacts.tamper)) {
            ESP_LOGW(TAG, "enrollment aborted");
            forget_partial(slot, have_id);
            event_log_add(DOOR_EVT_FAULT, have_id ? (int16_t)slot : -1, FM225_ERR_AUTHORIZATION, hal_millis());
            storage_save_events();
            return;
        }
        ESP_LOGI(TAG, "look %s", labels[i]);
        memset(&reply, 0, sizeof reply);
        n = fm225_build_enroll(name, dirs[i], 10u, tx, sizeof tx);
        if (transact(tx, n, FM225_CMD_ENROLL, &rx, 12000u) != TR_REPLY || !fm225_decode_reply(&rx, &reply) ||
            reply.result != FM225_OK || !reply.has_id || reply.id > FM225_SLOT_MAX) {
            ESP_LOGW(TAG, "enrollment failed at %s", labels[i]);
            forget_partial(slot, have_id);
            event_log_add(DOOR_EVT_FAULT, have_id ? (int16_t)slot : -1, reply.result, hal_millis());
            storage_save_events();
            return;
        }
        slot = reply.id;
        have_id = true;
    }
    ESP_LOGI(TAG, "slot %u enrolled but not authorized; maintenance command: allow %u %s", (unsigned)slot,
             (unsigned)slot, name);
    event_log_add(DOOR_EVT_ENROLL, (int16_t)slot, 0u, hal_millis());
    storage_save_events();
}

static bool reply_ok(const fm225_frame_t *frame) {
    fm225_reply_t reply;
    return fm225_decode_reply(frame, &reply) && reply.result == FM225_OK;
}

static void do_delete(uint16_t slot) {
    uint8_t tx[16];
    fm225_frame_t rx;
    size_t n = fm225_build_delete(slot, tx, sizeof tx);
    if (transact(tx, n, FM225_CMD_DELETE, &rx, 3000u) != TR_REPLY || !reply_ok(&rx)) {
        ESP_LOGW(TAG, "delete slot %u failed", (unsigned)slot);
        event_log_add(DOOR_EVT_FAULT, (int16_t)slot, FM225_CMD_DELETE, hal_millis());
        storage_save_events();
        return;
    }
    auth_remove(slot);
    storage_save_users();
    event_log_add(DOOR_EVT_DELETE, (int16_t)slot, 0u, hal_millis());
    storage_save_events();
    ESP_LOGI(TAG, "deleted slot %u", (unsigned)slot);
}

static void do_delete_all(void) {
    uint8_t tx[16];
    fm225_frame_t rx;
    uint16_t slot;
    size_t n = fm225_build_delete_all(tx, sizeof tx);
    if (transact(tx, n, FM225_CMD_DELETE_ALL, &rx, 5000u) != TR_REPLY || !reply_ok(&rx)) {
        ESP_LOGW(TAG, "delete all failed");
        return;
    }
    for (slot = 0u; slot < AUTH_CAPACITY; slot++) {
        auth_remove(slot);
    }
    storage_save_users();
    event_log_add(DOOR_EVT_DELETE, -1, FM225_CMD_DELETE_ALL, hal_millis());
    storage_save_events();
    ESP_LOGI(TAG, "deleted every module template and local allow record");
}

static bool maintenance_ok(void) {
    hal_contacts_t contacts;
    hal_read_contacts(&contacts);
    return door_enrollment_permitted(contacts.maintenance, contacts.tamper);
}

static void fm_task(void *arg) {
    (void)arg;
    if (!fm225_protocol_self_check()) {
        ESP_LOGE(TAG, "protocol self-check failed");
        event_log_add(DOOR_EVT_FAULT, -1, 1u, hal_millis());
        storage_save_events();
        vTaskSuspend(NULL);
    }
    vTaskDelay(pdMS_TO_TICKS(1000));
    while (!bringup()) {
        vTaskDelay(pdMS_TO_TICKS(5000));
    }
    for (;;) {
        fm_cmd_t cmd;
        if (xQueueReceive(s_cmds, &cmd, pdMS_TO_TICKS(100)) != pdTRUE) {
            continue;
        }
        s_busy = true;
        if (cmd.type == CMD_VERIFY) {
            do_verify();
        } else if (!maintenance_ok()) {
            ESP_LOGW(TAG, "maintenance switch is off or the enclosure is open");
        } else if (cmd.type == CMD_ENROLL) {
            do_enroll(cmd.name);
        } else if (cmd.type == CMD_DELETE) {
            do_delete(cmd.slot);
        } else if (cmd.type == CMD_DELETE_ALL) {
            do_delete_all();
        }
        s_busy = false;
    }
}

static bool enqueue(const fm_cmd_t *cmd) {
    if (s_cmds == NULL || s_busy) {
        return false;
    }
    return xQueueSend(s_cmds, cmd, 0) == pdTRUE;
}

void fm225_port_start(void) {
    uart_config_t cfg = {
        .baud_rate = 115200,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    s_cmds = xQueueCreate(1, sizeof(fm_cmd_t));
    s_results = xQueueCreate(4, sizeof(fm_result_t));
    ESP_ERROR_CHECK(uart_driver_install(FM_UART, 1024, 0, 0, NULL, 0));
    ESP_ERROR_CHECK(uart_param_config(FM_UART, &cfg));
    ESP_ERROR_CHECK(uart_set_pin(FM_UART, PIN_UART_TX, PIN_UART_RX, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
    xTaskCreate(fm_task, "fm225", 8192, NULL, 6, NULL);
}

bool fm225_request_verify(void) {
    fm_cmd_t cmd = {.type = CMD_VERIFY};
    return enqueue(&cmd);
}

bool fm225_request_enroll(const char *name) {
    fm_cmd_t cmd = {.type = CMD_ENROLL};
    if (name == NULL) {
        return false;
    }
    snprintf(cmd.name, sizeof cmd.name, "%s", name);
    return enqueue(&cmd);
}

bool fm225_request_delete(uint16_t slot) {
    fm_cmd_t cmd = {.type = CMD_DELETE, .slot = slot};
    return enqueue(&cmd);
}

bool fm225_request_delete_all(void) {
    fm_cmd_t cmd = {.type = CMD_DELETE_ALL};
    return enqueue(&cmd);
}

bool fm225_poll_result(fm_result_t *out) {
    if (s_results == NULL) {
        return false;
    }
    return xQueueReceive(s_results, out, 0) == pdTRUE;
}

const char *fm225_version(void) {
    return s_version;
}
