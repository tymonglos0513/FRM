#include "access_sm.h"
#include "authorization.h"
#include "debounce.h"
#include "door_logic.h"
#include "event_log.h"
#include "fm225_protocol.h"

#include <stdio.h>
#include <string.h>

static int g_failures;

#define EXPECT(cond)                                                                                          \
    do {                                                                                                      \
        if (!(cond)) {                                                                                        \
            fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond);                                  \
            g_failures++;                                                                                     \
        }                                                                                                     \
    } while (0)

static fm_parse_status_t feed(fm225_parser_t *parser, const uint8_t *bytes, size_t n, fm225_frame_t *frame) {
    fm_parse_status_t status = FM_PARSE_NEED_MORE;
    size_t i;
    for (i = 0u; i < n; i++) {
        status = fm225_parse_byte(parser, bytes[i], frame);
    }
    return status;
}

static void build_reply(fm225_frame_t *frame, uint8_t command, uint8_t result, const uint8_t *rest, uint16_t rest_len) {
    uint8_t payload[80];
    uint8_t raw[96];
    fm225_parser_t parser;
    size_t n;
    payload[0] = command;
    payload[1] = result;
    if (rest_len > 0u) {
        memcpy(&payload[2], rest, rest_len);
    }
    n = fm225_build(FM225_MSG_REPLY, payload, (uint16_t)(2u + rest_len), raw, sizeof raw);
    fm225_parser_init(&parser);
    EXPECT(feed(&parser, raw, n, frame) == FM_PARSE_FRAME);
}

static void test_protocol(void) {
    fm225_parser_t parser;
    fm225_frame_t frame;
    fm225_reply_t reply;
    fm225_face_note_t note;
    uint8_t raw[96];
    uint8_t bad[8];
    uint8_t rest[36];
    uint16_t slot = 99u;
    uint8_t code = 0u;
    char name[33];
    size_t n;
    static const uint8_t reset_reply[] = {0xEFu, 0xAAu, 0x00u, 0x00u, 0x02u, 0x10u, 0x00u, 0x12u};

    EXPECT(fm225_protocol_self_check());
    fm225_parser_init(&parser);
    EXPECT(feed(&parser, reset_reply, sizeof reset_reply, &frame) == FM_PARSE_FRAME);
    EXPECT(fm225_decode_reply(&frame, &reply));
    EXPECT(reply.command == FM225_CMD_RESET && reply.result == FM225_OK);

    memcpy(bad, reset_reply, sizeof bad);
    bad[7] ^= 0xFFu;
    fm225_parser_init(&parser);
    EXPECT(feed(&parser, bad, sizeof bad, &frame) == FM_PARSE_CHECKSUM);
    EXPECT(feed(&parser, reset_reply, sizeof reset_reply, &frame) == FM_PARSE_FRAME);

    memset(rest, 0, sizeof rest);
    rest[0] = 0x00;
    rest[1] = 0x05;
    memcpy(&rest[2], "Ada", 3);
    build_reply(&frame, FM225_CMD_VERIFY, FM225_OK, rest, 34u);
    EXPECT(fm225_judge_verify(&frame, &slot, name, sizeof name, &code) == FM_VERDICT_MATCH);
    EXPECT(slot == 5u);
    EXPECT(strcmp(name, "Ada") == 0);

    build_reply(&frame, FM225_CMD_VERIFY, FM225_ERR_REJECTED, NULL, 0u);
    EXPECT(fm225_judge_verify(&frame, &slot, name, sizeof name, &code) == FM_VERDICT_UNMATCHED);

    build_reply(&frame, FM225_CMD_VERIFY, FM225_ERR_LIVENESS, NULL, 0u);
    EXPECT(fm225_judge_verify(&frame, &slot, name, sizeof name, &code) == FM_VERDICT_INVALID);
    EXPECT(code == FM225_ERR_LIVENESS);

    build_reply(&frame, FM225_CMD_GET_STATUS, FM225_OK, rest, 34u);
    EXPECT(fm225_judge_verify(&frame, &slot, name, sizeof name, &code) == FM_VERDICT_INVALID);

    rest[0] = 0x00;
    rest[1] = 100u;
    build_reply(&frame, FM225_CMD_VERIFY, FM225_OK, rest, 34u);
    EXPECT(fm225_judge_verify(&frame, &slot, name, sizeof name, &code) == FM_VERDICT_INVALID);

    n = fm225_build_enroll("Ada", FM225_DIR_LEFT, 10u, raw, sizeof raw);
    EXPECT(n == 41u);
    EXPECT(raw[2] == FM225_CMD_ENROLL);
    EXPECT(raw[5] == 0u);
    EXPECT(raw[6] == 'A' && raw[7] == 'd' && raw[8] == 'a');
    EXPECT(raw[5u + 33u] == FM225_DIR_LEFT);
    EXPECT(raw[5u + 34u] == 10u);

    n = fm225_build_verify(raw, sizeof raw);
    EXPECT(n == 8u);
    EXPECT(raw[2] == FM225_CMD_VERIFY);
    EXPECT(raw[5] == 0u && raw[6] == 0u);

    {
        uint8_t note_payload[17];
        uint8_t note_raw[32];
        memset(note_payload, 0, sizeof note_payload);
        note_payload[0] = FM225_NOTE_FACE;
        note_payload[1] = 0x02;
        note_payload[2] = 0x00;
        note_payload[11] = 0xE8;
        note_payload[12] = 0xFFu;
        n = fm225_build(FM225_MSG_NOTE, note_payload, 17u, note_raw, sizeof note_raw);
        fm225_parser_init(&parser);
        EXPECT(feed(&parser, note_raw, n, &frame) == FM_PARSE_FRAME);
        EXPECT(fm225_decode_face_note(&frame, &note));
        EXPECT(note.status == 2);
        EXPECT(note.yaw == -24);
        EXPECT(fm225_judge_verify(&frame, &slot, name, sizeof name, &code) == FM_VERDICT_IGNORE);
    }
}

static void test_authorization(void) {
    uint8_t blob[AUTH_BLOB_SIZE];
    auth_user_t user;

    auth_init();
    EXPECT(auth_evaluate(0u, false, 0u, 0u) == AUTH_UNKNOWN_SLOT);
    EXPECT(!auth_allow_always(0u, ""));
    EXPECT(!auth_allow_always(0u, "bad/name"));
    EXPECT(auth_allow_always(0u, "Ada"));
    EXPECT(auth_evaluate(0u, false, 0u, 0u) == AUTH_GRANTED);
    EXPECT(auth_set_enabled(0u, false));
    EXPECT(auth_evaluate(0u, false, 0u, 0u) == AUTH_DISABLED);
    EXPECT(auth_set_enabled(0u, true));

    EXPECT(auth_upsert(4u, "Ben", true, 0x3Eu, 8u * 60u, 17u * 60u));
    EXPECT(auth_evaluate(4u, false, 1u, 600u) == AUTH_TIME_UNAVAILABLE);
    EXPECT(auth_evaluate(4u, true, 1u, 8u * 60u) == AUTH_GRANTED);
    EXPECT(auth_evaluate(4u, true, 1u, 7u * 60u) == AUTH_OUTSIDE_SCHEDULE);
    EXPECT(auth_evaluate(4u, true, 0u, 10u * 60u) == AUTH_OUTSIDE_SCHEDULE);

    EXPECT(auth_export_half(0, blob, sizeof blob) == AUTH_BLOB_SIZE);
    auth_init();
    EXPECT(auth_used_count() == 0u);
    EXPECT(auth_import_half(blob, sizeof blob));
    EXPECT(auth_get(0u, &user) && user.enabled && strcmp(user.name, "Ada") == 0);
    EXPECT(auth_evaluate(4u, true, 2u, 12u * 60u) == AUTH_GRANTED);
}

static void prime(acc_t *s, acc_input_t *in) {
    memset(in, 0, sizeof(*in));
    in->door_closed = true;
    acc_init(s);
    acc_step(s, in, 0u);
}

static void test_state_machine(void) {
    acc_t s;
    acc_input_t in;
    uint32_t t;
    int i;

    prime(&s, &in);
    EXPECT(s.state == ACC_LOCKED);
    EXPECT(!s.lock_output);

    in.scan_edge = true;
    acc_step(&s, &in, 1000u);
    EXPECT(s.state == ACC_SCANNING);
    EXPECT(s.issue_scan);
    EXPECT(!s.lock_output);
    in.scan_edge = false;

    in.face = ACC_FACE_MATCH_GRANTED;
    in.face_slot = 3u;
    acc_step(&s, &in, 1100u);
    EXPECT(s.lock_output);
    EXPECT(s.evt_granted);
    EXPECT(s.green);
    in.face = ACC_FACE_NONE;
    acc_step(&s, &in, 1100u + ACC_UNLOCK_MS - 1u);
    EXPECT(s.lock_output);
    acc_step(&s, &in, 1100u + ACC_UNLOCK_MS);
    EXPECT(!s.lock_output);
    EXPECT(s.state == ACC_LOCKED);

    prime(&s, &in);
    in.face = ACC_FACE_MATCH_GRANTED;
    acc_step(&s, &in, 50u);
    EXPECT(!s.lock_output);
    EXPECT(s.evt_stale);
    in.face = ACC_FACE_NONE;

    in.scan_edge = true;
    acc_step(&s, &in, 100u);
    in.scan_edge = false;
    acc_step(&s, &in, 100u + ACC_SCAN_TIMEOUT_MS);
    EXPECT(s.evt_timeout);
    EXPECT(s.state == ACC_LOCKED);
    in.face = ACC_FACE_MATCH_GRANTED;
    acc_step(&s, &in, 100u + ACC_SCAN_TIMEOUT_MS + 1u);
    EXPECT(s.evt_stale);
    EXPECT(!s.lock_output);

    prime(&s, &in);
    t = 1000u;
    for (i = 0; i < (int)ACC_FAIL_LIMIT; i++) {
        in.scan_edge = true;
        in.face = ACC_FACE_NONE;
        acc_step(&s, &in, t);
        EXPECT(s.issue_scan);
        in.scan_edge = false;
        in.face = ACC_FACE_UNMATCHED;
        acc_step(&s, &in, t + 10u);
        EXPECT(!s.lock_output);
        in.face = ACC_FACE_NONE;
        t += 1000u;
    }
    EXPECT(s.state == ACC_LOCKOUT);
    EXPECT(s.evt_lockout);
    in.scan_edge = true;
    acc_step(&s, &in, t);
    EXPECT(!s.issue_scan);
    in.scan_edge = false;
    in.exit_edge = true;
    acc_step(&s, &in, t + 10u);
    EXPECT(s.lock_output);
    EXPECT(s.evt_exit);
    in.exit_edge = false;
    acc_step(&s, &in, t + 10u + ACC_UNLOCK_MS);
    EXPECT(!s.lock_output);
    EXPECT(s.state == ACC_LOCKOUT);

    prime(&s, &in);
    in.door_closed = false;
    acc_step(&s, &in, 200u);
    EXPECT(s.evt_forced);
    EXPECT(s.red);
    in.door_closed = true;
    acc_step(&s, &in, 300u);
    EXPECT(!s.forced);

    prime(&s, &in);
    in.scan_edge = true;
    acc_step(&s, &in, 1000u);
    in.scan_edge = false;
    in.face = ACC_FACE_MATCH_GRANTED;
    acc_step(&s, &in, 1100u);
    in.face = ACC_FACE_NONE;
    in.door_closed = false;
    acc_step(&s, &in, 1200u);
    EXPECT(!s.evt_forced);
    EXPECT(s.state == ACC_UNLOCKED || s.state == ACC_DOOR_OPEN);
    acc_step(&s, &in, 1100u + ACC_UNLOCK_MS + ACC_GRANT_GRACE_MS - 1u);
    EXPECT(!s.forced);
    in.door_closed = true;
    acc_step(&s, &in, 1100u + ACC_UNLOCK_MS + ACC_GRANT_GRACE_MS);
    in.door_closed = false;
    acc_step(&s, &in, 1100u + ACC_UNLOCK_MS + ACC_GRANT_GRACE_MS + 1u);
    EXPECT(s.evt_forced);

    prime(&s, &in);
    in.scan_edge = true;
    acc_step(&s, &in, 1000u);
    in.scan_edge = false;
    in.face = ACC_FACE_MATCH_GRANTED;
    acc_step(&s, &in, 1000u);
    in.face = ACC_FACE_NONE;
    in.door_closed = false;
    acc_step(&s, &in, 2000u);
    acc_step(&s, &in, 2000u + ACC_HELD_OPEN_MS);
    EXPECT(s.evt_held);

    prime(&s, &in);
    in.tamper = true;
    in.scan_edge = true;
    acc_step(&s, &in, 10u);
    EXPECT(s.evt_tamper);
    EXPECT(!s.issue_scan);
    in.scan_edge = false;
    in.exit_edge = true;
    acc_step(&s, &in, 20u);
    EXPECT(s.lock_output);
    in.exit_edge = false;

    prime(&s, &in);
    in.scan_edge = true;
    acc_step(&s, &in, 50u);
    in.scan_edge = false;
    in.cancel_scan = true;
    acc_step(&s, &in, 60u);
    EXPECT(s.state == ACC_LOCKED);
    EXPECT(s.fail_count == 0u);
    EXPECT(!s.lock_output);
    in.cancel_scan = false;

    prime(&s, &in);
    in.scan_edge = true;
    acc_step(&s, &in, 100u);
    in.scan_edge = false;
    in.supply_failed = true;
    in.face = ACC_FACE_MATCH_GRANTED;
    acc_step(&s, &in, 150u);
    EXPECT(!s.lock_output);
    EXPECT(s.evt_denied);
    EXPECT(s.fail_count == 0u);
    in.face = ACC_FACE_NONE;
    in.exit_edge = true;
    acc_step(&s, &in, 200u);
    EXPECT(s.lock_output);
}

static void test_classify_and_debounce(void) {
    fm225_frame_t frame;
    uint8_t rest[36];
    uint16_t slot = 0u;
    uint8_t code = 0u;
    acc_t s;
    acc_input_t in;
    debounce_t d;
    bool rose = false;
    bool fell = false;
    bool stable;

    auth_init();
    memset(rest, 0, sizeof rest);
    rest[0] = 0x00;
    rest[1] = 0x00;
    memcpy(&rest[2], "Ada", 3);
    build_reply(&frame, FM225_CMD_VERIFY, FM225_OK, rest, 34u);
    EXPECT(door_classify_verify(&frame, &slot, &code, false, 0u, 0u) == ACC_FACE_MATCH_DENIED);

    EXPECT(auth_allow_always(0u, "Ada"));
    EXPECT(door_classify_verify(&frame, &slot, &code, false, 0u, 0u) == ACC_FACE_MATCH_GRANTED);
    EXPECT(!door_enrollment_permitted(false, false));
    EXPECT(!door_enrollment_permitted(true, true));
    EXPECT(door_enrollment_permitted(true, false));

    prime(&s, &in);
    in.scan_edge = true;
    acc_step(&s, &in, 10u);
    in.scan_edge = false;
    in.face = door_classify_verify(&frame, &slot, &code, false, 0u, 0u);
    in.face_slot = slot;
    acc_step(&s, &in, 20u);
    EXPECT(s.lock_output);
    EXPECT(s.evt_granted);

    auth_set_enabled(0u, false);
    prime(&s, &in);
    in.scan_edge = true;
    acc_step(&s, &in, 10u);
    in.scan_edge = false;
    in.face = door_classify_verify(&frame, &slot, &code, false, 0u, 0u);
    in.face_slot = slot;
    acc_step(&s, &in, 20u);
    EXPECT(!s.lock_output);
    EXPECT(s.evt_denied);

    debounce_init(&d);
    stable = debounce_update(&d, false, 0u, 30u, &rose, &fell);
    EXPECT(!stable && !rose);
    stable = debounce_update(&d, true, 10u, 30u, &rose, &fell);
    EXPECT(!stable && !rose);
    stable = debounce_update(&d, true, 40u, 30u, &rose, &fell);
    EXPECT(stable && rose);
    stable = debounce_update(&d, false, 50u, 30u, &rose, &fell);
    EXPECT(stable && !fell);
    stable = debounce_update(&d, false, 80u, 30u, &rose, &fell);
    EXPECT(!stable && fell);

    event_log_init();
    event_log_set_boot(3u);
    event_log_add(DOOR_EVT_GRANTED, 0, 0u, 20u);
    EXPECT(event_log_count() == 1u);
}

static void test_event_roundtrip(void) {
    uint8_t blob[EVENT_BLOB_SIZE];
    door_event_t ev;
    int i;

    event_log_init();
    event_log_set_boot(9u);
    for (i = 0; i < (int)EVENT_LOG_CAP + 3; i++) {
        event_log_add(DOOR_EVT_DENIED, (int16_t)i, 1u, (uint32_t)i);
    }
    EXPECT(event_log_count() == EVENT_LOG_CAP);
    EXPECT(event_log_export(blob, sizeof blob) == EVENT_BLOB_SIZE);
    event_log_init();
    EXPECT(event_log_import(blob, sizeof blob));
    EXPECT(event_log_newest(0u, &ev));
    EXPECT(ev.type == DOOR_EVT_DENIED);
    EXPECT(ev.boot == 9u);
    EXPECT(ev.slot == (int16_t)(EVENT_LOG_CAP + 2));
}

int main(void) {
    test_protocol();
    test_authorization();
    test_state_machine();
    test_classify_and_debounce();
    test_event_roundtrip();
    if (g_failures != 0) {
        fprintf(stderr, "%d check(s) failed\n", g_failures);
        return 1;
    }
    printf("fm225 door logic tests passed\n");
    return 0;
}
