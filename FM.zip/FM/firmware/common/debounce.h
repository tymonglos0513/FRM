#pragma once

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    bool init;
    bool stable;
    bool last_raw;
    uint32_t change_ms;
} debounce_t;

void debounce_init(debounce_t *d);
bool debounce_update(debounce_t *d, bool raw, uint32_t now_ms, uint32_t filter_ms, bool *rose, bool *fell);
