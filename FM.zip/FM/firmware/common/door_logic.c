#include "door_logic.h"

#include "authorization.h"

acc_face_kind_t door_classify_verify(const fm225_frame_t *frame, uint16_t *slot_out, uint8_t *code_out,
                                     bool time_known, uint8_t weekday, uint16_t minute_of_day) {
    uint16_t slot = 0u;
    uint8_t code = 0u;
    char name[FM225_NAME_LEN + 1u];
    fm_verdict_t verdict = fm225_judge_verify(frame, &slot, name, sizeof name, &code);
    auth_result_t auth;

    if (code_out != NULL) {
        *code_out = code;
    }
    if (slot_out != NULL) {
        *slot_out = slot;
    }
    if (verdict == FM_VERDICT_UNMATCHED) {
        return ACC_FACE_UNMATCHED;
    }
    if (verdict == FM_VERDICT_INVALID) {
        return ACC_FACE_INVALID;
    }
    if (verdict != FM_VERDICT_MATCH) {
        return ACC_FACE_NONE;
    }
    auth = auth_evaluate(slot, time_known, weekday, minute_of_day);
    return (auth == AUTH_GRANTED) ? ACC_FACE_MATCH_GRANTED : ACC_FACE_MATCH_DENIED;
}

bool door_enrollment_permitted(bool maintenance, bool tamper) {
    return maintenance && !tamper;
}
