#pragma once

void data_lock_init(void);
void data_lock(void);
void data_unlock(void);
