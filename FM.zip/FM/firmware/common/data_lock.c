#include "data_lock.h"

#ifdef DOOR_IDF
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

static SemaphoreHandle_t s_mu;

void data_lock_init(void) {
    if (s_mu == NULL) {
        s_mu = xSemaphoreCreateRecursiveMutex();
    }
}

void data_lock(void) {
    if (s_mu != NULL) {
        xSemaphoreTakeRecursive(s_mu, portMAX_DELAY);
    }
}

void data_unlock(void) {
    if (s_mu != NULL) {
        xSemaphoreGiveRecursive(s_mu);
    }
}
#else
void data_lock_init(void) {}
void data_lock(void) {}
void data_unlock(void) {}
#endif
