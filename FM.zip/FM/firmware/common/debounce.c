#include "debounce.h"

#include <string.h>

void debounce_init(debounce_t *d) {
    memset(d, 0, sizeof(*d));
}

bool debounce_update(debounce_t *d, bool raw, uint32_t now_ms, uint32_t filter_ms, bool *rose, bool *fell) {
    *rose = false;
    *fell = false;
    if (!d->init) {
        d->init = true;
        d->stable = raw;
        d->last_raw = raw;
        d->change_ms = now_ms;
        return d->stable;
    }
    if (raw != d->last_raw) {
        d->last_raw = raw;
        d->change_ms = now_ms;
    }
    if (raw != d->stable && (uint32_t)(now_ms - d->change_ms) >= filter_ms) {
        bool previous = d->stable;
        d->stable = raw;
        *rose = d->stable && !previous;
        *fell = !d->stable && previous;
    }
    return d->stable;
}
