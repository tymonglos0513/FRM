#include "access_sm.h"

#include <string.h>

static bool due(uint32_t now, uint32_t deadline) {
    return (int32_t)(now - deadline) >= 0;
}

static bool active_until(uint32_t now, uint32_t deadline) {
    return (int32_t)(deadline - now) > 0;
}

static void clear_events(acc_t *s) {
    s->issue_scan = false;
    s->evt_granted = false;
    s->evt_denied = false;
    s->evt_unmatched = false;
    s->evt_exit = false;
    s->evt_forced = false;
    s->evt_held = false;
    s->evt_tamper = false;
    s->evt_lockout = false;
    s->evt_timeout = false;
    s->evt_stale = false;
}

static void arm_unlock(acc_t *s, uint32_t now) {
    s->unlock_armed = true;
    s->unlock_until = now + ACC_UNLOCK_MS;
    s->grant_armed = true;
    s->grant_until = now + ACC_UNLOCK_MS + ACC_GRANT_GRACE_MS;
    s->scanning = false;
}

static void deny(acc_t *s, uint32_t now) {
    s->red_until = now + ACC_DENY_MS;
    s->beep_until = now + 200u;
    s->evt_denied = true;
}

static void register_fail(acc_t *s, uint32_t now) {
    if (s->fail_count == 0u || (int32_t)(now - s->fail_window_start) > (int32_t)ACC_FAIL_WINDOW_MS) {
        s->fail_window_start = now;
        s->fail_count = 1u;
    } else {
        s->fail_count++;
    }
    if (s->fail_count >= ACC_FAIL_LIMIT) {
        s->lockout_active = true;
        s->lockout_until = now + ACC_LOCKOUT_MS;
        s->scanning = false;
        s->evt_lockout = true;
    }
}

void acc_init(acc_t *s) {
    memset(s, 0, sizeof(*s));
    s->state = ACC_LOCKED;
}

void acc_step(acc_t *s, const acc_input_t *in, uint32_t now_ms) {
    bool door_opened;
    bool within_grant;
    bool alarm;

    clear_events(s);
    if (!s->primed) {
        s->primed = true;
        s->door_closed_prev = in->door_closed;
    }

    door_opened = s->door_closed_prev && !in->door_closed;
    s->door_closed_prev = in->door_closed;

    if (s->lockout_active && due(now_ms, s->lockout_until)) {
        s->lockout_active = false;
        s->fail_count = 0u;
    }
    if (s->unlock_armed && due(now_ms, s->unlock_until)) {
        s->unlock_armed = false;
    }
    if (s->scanning && due(now_ms, s->scan_until)) {
        s->scanning = false;
        s->evt_timeout = true;
    }
    if (in->cancel_scan) {
        s->scanning = false;
    }

    if (in->exit_edge) {
        arm_unlock(s, now_ms);
        s->evt_exit = true;
    }

    if (in->face != ACC_FACE_NONE) {
        bool credential_reject = in->face == ACC_FACE_UNMATCHED || in->face == ACC_FACE_INVALID ||
                                 in->face == ACC_FACE_MATCH_DENIED;
        s->last_slot = in->face_slot;
        if (!s->scanning) {
            s->evt_stale = true;
        } else if (in->face == ACC_FACE_MATCH_GRANTED && !in->tamper && !in->supply_failed) {
            s->fail_count = 0u;
            arm_unlock(s, now_ms);
            s->evt_granted = true;
        } else {
            s->scanning = false;
            if (in->face == ACC_FACE_UNMATCHED) {
                s->evt_unmatched = true;
            }
            deny(s, now_ms);
            if (credential_reject && !in->tamper && !in->supply_failed) {
                register_fail(s, now_ms);
            }
        }
    }

    if (in->scan_edge && !s->scanning && !s->lockout_active && !in->tamper && !in->supply_failed &&
        in->door_closed && !s->unlock_armed) {
        s->scanning = true;
        s->scan_until = now_ms + ACC_SCAN_TIMEOUT_MS;
        s->issue_scan = true;
    }

    within_grant = s->grant_armed && !due(now_ms, s->grant_until);
    if (door_opened && !within_grant) {
        s->forced = true;
        s->evt_forced = true;
    }
    if (in->door_closed) {
        s->forced = false;
        s->held = false;
        s->door_open_since_valid = false;
    } else if (!s->door_open_since_valid) {
        s->door_open_since = now_ms;
        s->door_open_since_valid = true;
    } else if ((int32_t)(now_ms - s->door_open_since) >= (int32_t)ACC_HELD_OPEN_MS) {
        if (!s->held) {
            s->evt_held = true;
        }
        s->held = true;
    }

    if (in->tamper && !s->tamper_prev) {
        s->evt_tamper = true;
    }
    s->tamper_prev = in->tamper;

    s->lock_output = s->unlock_armed;
    s->green = s->lock_output;
    alarm = s->forced || s->held || in->tamper;
    s->buzzer = active_until(now_ms, s->beep_until) || (alarm && ((now_ms / 200u) % 5u) == 0u);
    s->red = active_until(now_ms, s->red_until) || alarm;

    if (s->lock_output) {
        s->state = ACC_UNLOCKED;
    } else if (s->scanning) {
        s->state = ACC_SCANNING;
    } else if (s->lockout_active) {
        s->state = ACC_LOCKOUT;
    } else if (!in->door_closed && within_grant) {
        s->state = ACC_DOOR_OPEN;
    } else {
        s->state = ACC_LOCKED;
    }
}

const char *acc_state_name(acc_state_t state) {
    switch (state) {
    case ACC_LOCKED:
        return "locked";
    case ACC_SCANNING:
        return "scanning";
    case ACC_UNLOCKED:
        return "unlocked";
    case ACC_DOOR_OPEN:
        return "door-open";
    case ACC_LOCKOUT:
        return "lockout";
    default:
        return "unknown";
    }
}
