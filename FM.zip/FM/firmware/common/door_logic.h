#pragma once

#include "access_sm.h"
#include "fm225_protocol.h"

#include <stdbool.h>
#include <stdint.h>

/* Combines a VERIFY frame with the local allow-list.
 * There is no realtime clock in this revision, so the door task passes
 * time_known = false. A restricted schedule then fails closed. The console
 * allow command writes an always-valid schedule. */
acc_face_kind_t door_classify_verify(const fm225_frame_t *frame, uint16_t *slot_out, uint8_t *code_out,
                                     bool time_known, uint8_t weekday, uint16_t minute_of_day);

bool door_enrollment_permitted(bool maintenance, bool tamper);
