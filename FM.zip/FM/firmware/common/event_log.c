#include "event_log.h"

#include "data_lock.h"

#include <string.h>

static door_event_t g_events[EVENT_LOG_CAP];
static size_t g_count;
static size_t g_next;
static uint32_t g_boot;

static void put_u16(uint8_t *p, uint16_t v) {
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)(v >> 8);
}

static void put_u32(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)((v >> 8) & 0xFFu);
    p[2] = (uint8_t)((v >> 16) & 0xFFu);
    p[3] = (uint8_t)((v >> 24) & 0xFFu);
}

static uint16_t get_u16(const uint8_t *p) {
    return (uint16_t)p[0] | (uint16_t)((uint16_t)p[1] << 8);
}

static uint32_t get_u32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

void event_log_init(void) {
    data_lock();
    memset(g_events, 0, sizeof g_events);
    g_count = 0u;
    g_next = 0u;
    g_boot = 0u;
    data_unlock();
}

void event_log_set_boot(uint32_t boot) {
    data_lock();
    g_boot = boot;
    data_unlock();
}

void event_log_add(uint16_t type, int16_t slot, uint16_t code, uint32_t uptime_ms) {
    data_lock();
    g_events[g_next].boot = g_boot;
    g_events[g_next].uptime_ms = uptime_ms;
    g_events[g_next].type = type;
    g_events[g_next].slot = slot;
    g_events[g_next].code = code;
    g_next = (g_next + 1u) % EVENT_LOG_CAP;
    if (g_count < EVENT_LOG_CAP) {
        g_count++;
    }
    data_unlock();
}

size_t event_log_count(void) {
    size_t count;
    data_lock();
    count = g_count;
    data_unlock();
    return count;
}

bool event_log_newest(size_t index_from_newest, door_event_t *out) {
    bool ok = false;
    data_lock();
    if (index_from_newest < g_count) {
        size_t slot = (g_next + EVENT_LOG_CAP - 1u - index_from_newest) % EVENT_LOG_CAP;
        *out = g_events[slot];
        ok = true;
    }
    data_unlock();
    return ok;
}

const char *event_type_name(uint16_t type) {
    switch (type) {
    case DOOR_EVT_BOOT:
        return "boot";
    case DOOR_EVT_GRANTED:
        return "granted";
    case DOOR_EVT_DENIED:
        return "denied";
    case DOOR_EVT_UNMATCHED:
        return "unmatched";
    case DOOR_EVT_EXIT:
        return "exit";
    case DOOR_EVT_FORCED:
        return "forced-open";
    case DOOR_EVT_HELD:
        return "held-open";
    case DOOR_EVT_TAMPER:
        return "tamper";
    case DOOR_EVT_LOCKOUT:
        return "lockout";
    case DOOR_EVT_ENROLL:
        return "enroll";
    case DOOR_EVT_REVOKE:
        return "revoke";
    case DOOR_EVT_DELETE:
        return "delete";
    case DOOR_EVT_BROWNOUT:
        return "brownout";
    case DOOR_EVT_SCAN_TIMEOUT:
        return "scan-timeout";
    case DOOR_EVT_STALE:
        return "stale-frame";
    case DOOR_EVT_FAULT:
        return "fault";
    default:
        return "other";
    }
}

size_t event_log_export(uint8_t *dst, size_t cap) {
    size_t i;
    if (cap < EVENT_BLOB_SIZE) {
        return 0u;
    }
    data_lock();
    memset(dst, 0, EVENT_BLOB_SIZE);
    dst[0] = 'F';
    dst[1] = 'M';
    dst[2] = 'E';
    dst[3] = '1';
    put_u16(&dst[4], (uint16_t)g_count);
    put_u16(&dst[6], (uint16_t)g_next);
    for (i = 0u; i < EVENT_LOG_CAP; i++) {
        uint8_t *rec = &dst[8u + i * EVENT_REC_SIZE];
        put_u32(&rec[0], g_events[i].boot);
        put_u32(&rec[4], g_events[i].uptime_ms);
        put_u16(&rec[8], g_events[i].type);
        put_u16(&rec[10], (uint16_t)g_events[i].slot);
        put_u16(&rec[12], g_events[i].code);
    }
    data_unlock();
    return EVENT_BLOB_SIZE;
}

bool event_log_import(const uint8_t *src, size_t len) {
    size_t i;
    size_t count;
    size_t next;
    door_event_t imported[EVENT_LOG_CAP];
    if (src == NULL || len != EVENT_BLOB_SIZE) {
        return false;
    }
    if (src[0] != 'F' || src[1] != 'M' || src[2] != 'E' || src[3] != '1') {
        return false;
    }
    count = get_u16(&src[4]);
    next = get_u16(&src[6]);
    if (count > EVENT_LOG_CAP || next >= EVENT_LOG_CAP) {
        return false;
    }
    data_lock();
    memset(imported, 0, sizeof imported);
    for (i = 0u; i < EVENT_LOG_CAP; i++) {
        const uint8_t *rec = &src[8u + i * EVENT_REC_SIZE];
        imported[i].boot = get_u32(&rec[0]);
        imported[i].uptime_ms = get_u32(&rec[4]);
        imported[i].type = get_u16(&rec[8]);
        imported[i].slot = (int16_t)get_u16(&rec[10]);
        imported[i].code = get_u16(&rec[12]);
    }
    memcpy(g_events, imported, sizeof g_events);
    g_count = count;
    g_next = next;
    data_unlock();
    return true;
}
