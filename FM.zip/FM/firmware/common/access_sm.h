#pragma once

#include <stdbool.h>
#include <stdint.h>

/* Times are milliseconds from an arbitrary clock. Subtraction handles wrap. */

#define ACC_UNLOCK_MS 5000u
#define ACC_GRANT_GRACE_MS 10000u
#define ACC_SCAN_TIMEOUT_MS 8000u
#define ACC_HELD_OPEN_MS 30000u
#define ACC_FAIL_LIMIT 5u
#define ACC_FAIL_WINDOW_MS 60000u
#define ACC_LOCKOUT_MS 30000u
#define ACC_DENY_MS 1000u

typedef enum {
    ACC_LOCKED = 0,
    ACC_SCANNING,
    ACC_UNLOCKED,
    ACC_DOOR_OPEN,
    ACC_LOCKOUT
} acc_state_t;

typedef enum {
    ACC_FACE_NONE = 0,
    ACC_FACE_MATCH_GRANTED,
    ACC_FACE_MATCH_DENIED,
    ACC_FACE_UNMATCHED,
    ACC_FACE_INVALID
} acc_face_kind_t;

typedef struct {
    bool door_closed;
    bool exit_edge;
    bool scan_edge;
    bool cancel_scan;
    bool tamper;
    bool supply_failed;
    acc_face_kind_t face;
    uint16_t face_slot;
    uint8_t face_code;
} acc_input_t;

typedef struct {
    acc_state_t state;
    bool primed;
    bool door_closed_prev;
    bool tamper_prev;
    bool scanning;
    bool unlock_armed;
    bool grant_armed;
    bool lockout_active;
    bool forced;
    bool held;
    bool door_open_since_valid;
    uint32_t unlock_until;
    uint32_t grant_until;
    uint32_t scan_until;
    uint32_t lockout_until;
    uint32_t door_open_since;
    uint32_t fail_window_start;
    uint32_t red_until;
    uint32_t beep_until;
    uint8_t fail_count;
    uint16_t last_slot;

    bool lock_output;
    bool green;
    bool red;
    bool buzzer;
    bool issue_scan;
    bool evt_granted;
    bool evt_denied;
    bool evt_unmatched;
    bool evt_exit;
    bool evt_forced;
    bool evt_held;
    bool evt_tamper;
    bool evt_lockout;
    bool evt_timeout;
    bool evt_stale;
} acc_t;

void acc_init(acc_t *s);
void acc_step(acc_t *s, const acc_input_t *in, uint32_t now_ms);
const char *acc_state_name(acc_state_t state);
