#include "fm225_protocol.h"

#include <string.h>

#define ST_EF 0u
#define ST_AA 1u
#define ST_MSG 2u
#define ST_LEN_H 3u
#define ST_LEN_L 4u
#define ST_DATA 5u
#define ST_SUM 6u

static void copy_text(char *dst, size_t cap, const uint8_t *src, size_t len) {
    size_t n;
    size_t i;
    if (cap == 0u) {
        return;
    }
    n = len;
    if (n >= cap) {
        n = cap - 1u;
    }
    for (i = 0u; i < n; i++) {
        unsigned char c = src[i];
        if (c < 32u || c > 126u) {
            dst[i] = '.';
        } else {
            dst[i] = (char)c;
        }
    }
    dst[n] = '\0';
}

void fm225_parser_init(fm225_parser_t *parser) {
    memset(parser, 0, sizeof(*parser));
    parser->state = ST_EF;
}

fm_parse_status_t fm225_parse_byte(fm225_parser_t *parser, uint8_t byte, fm225_frame_t *out) {
    switch (parser->state) {
    case ST_EF:
        parser->state = (byte == FM225_START_HI) ? ST_AA : ST_EF;
        return FM_PARSE_NEED_MORE;
    case ST_AA:
        if (byte == FM225_START_LO) {
            parser->state = ST_MSG;
        } else {
            parser->state = (byte == FM225_START_HI) ? ST_AA : ST_EF;
        }
        return FM_PARSE_NEED_MORE;
    case ST_MSG:
        parser->msg = byte;
        parser->checksum = byte;
        parser->state = ST_LEN_H;
        return FM_PARSE_NEED_MORE;
    case ST_LEN_H:
        parser->length = (uint16_t)((uint16_t)byte << 8);
        parser->checksum ^= byte;
        parser->state = ST_LEN_L;
        return FM_PARSE_NEED_MORE;
    case ST_LEN_L:
        parser->length = (uint16_t)(parser->length | byte);
        parser->checksum ^= byte;
        parser->index = 0u;
        parser->overflow = parser->length > FM225_MAX_DATA;
        parser->state = (parser->length == 0u) ? ST_SUM : ST_DATA;
        return FM_PARSE_NEED_MORE;
    case ST_DATA:
        if (!parser->overflow) {
            parser->data[parser->index] = byte;
        }
        parser->checksum ^= byte;
        parser->index++;
        if (parser->index >= parser->length) {
            parser->state = ST_SUM;
        }
        return FM_PARSE_NEED_MORE;
    case ST_SUM: {
        fm_parse_status_t status;
        if (byte != parser->checksum) {
            status = FM_PARSE_CHECKSUM;
        } else if (parser->overflow) {
            status = FM_PARSE_OVERSIZE;
        } else {
            out->msg = parser->msg;
            out->length = parser->length;
            if (parser->length > 0u) {
                memcpy(out->data, parser->data, parser->length);
            }
            status = FM_PARSE_FRAME;
        }
        parser->state = ST_EF;
        return status;
    }
    default:
        parser->state = ST_EF;
        return FM_PARSE_NEED_MORE;
    }
}

size_t fm225_build(uint8_t msg, const uint8_t *data, uint16_t length, uint8_t *out, size_t cap) {
    uint16_t i;
    uint8_t sum;
    if (cap < (size_t)length + 6u) {
        return 0u;
    }
    out[0] = FM225_START_HI;
    out[1] = FM225_START_LO;
    out[2] = msg;
    out[3] = (uint8_t)(length >> 8);
    out[4] = (uint8_t)(length & 0xFFu);
    sum = (uint8_t)(msg ^ out[3] ^ out[4]);
    for (i = 0u; i < length; i++) {
        out[5u + i] = data[i];
        sum ^= data[i];
    }
    out[5u + length] = sum;
    return (size_t)length + 6u;
}

size_t fm225_build_reset(uint8_t *out, size_t cap) {
    return fm225_build(FM225_CMD_RESET, NULL, 0u, out, cap);
}

size_t fm225_build_status(uint8_t *out, size_t cap) {
    return fm225_build(FM225_CMD_GET_STATUS, NULL, 0u, out, cap);
}

size_t fm225_build_version(uint8_t *out, size_t cap) {
    return fm225_build(FM225_CMD_GET_VERSION, NULL, 0u, out, cap);
}

size_t fm225_build_verify(uint8_t *out, size_t cap) {
    /* Two zero argument bytes, matching the ESPHome hlk_fm22x verify command.
     * The Hi-Link manual describes timeout fields here; do not invent new
     * values until that manual is in hand. */
    static const uint8_t data[2] = {0u, 0u};
    return fm225_build(FM225_CMD_VERIFY, data, 2u, out, cap);
}

size_t fm225_build_enroll(const char *name, uint8_t direction, uint8_t timeout_s, uint8_t *out, size_t cap) {
    uint8_t data[35];
    size_t n = 0u;
    memset(data, 0, sizeof data);
    if (name != NULL) {
        while (name[n] != '\0' && n < 31u) {
            data[1u + n] = (uint8_t)name[n];
            n++;
        }
    }
    data[33] = direction;
    data[34] = timeout_s;
    return fm225_build(FM225_CMD_ENROLL, data, 35u, out, cap);
}

size_t fm225_build_delete(uint16_t slot, uint8_t *out, size_t cap) {
    uint8_t data[2];
    data[0] = (uint8_t)(slot >> 8);
    data[1] = (uint8_t)(slot & 0xFFu);
    return fm225_build(FM225_CMD_DELETE, data, 2u, out, cap);
}

size_t fm225_build_delete_all(uint8_t *out, size_t cap) {
    return fm225_build(FM225_CMD_DELETE_ALL, NULL, 0u, out, cap);
}

bool fm225_decode_reply(const fm225_frame_t *frame, fm225_reply_t *reply) {
    memset(reply, 0, sizeof(*reply));
    if (frame->msg != FM225_MSG_REPLY || frame->length < 2u) {
        return false;
    }
    reply->command = frame->data[0];
    reply->result = frame->data[1];
    if (frame->length >= 4u) {
        reply->has_id = true;
        reply->id = (uint16_t)(((uint16_t)frame->data[2] << 8) | frame->data[3]);
    }
    if (reply->command == FM225_CMD_VERIFY && frame->length >= 4u + FM225_NAME_LEN) {
        copy_text(reply->name, sizeof reply->name, &frame->data[4], FM225_NAME_LEN);
    } else if (reply->command == FM225_CMD_ENROLL && frame->length >= 5u) {
        reply->direction = frame->data[4];
    } else if (reply->command == FM225_CMD_GET_VERSION && frame->length > 2u) {
        size_t n = (size_t)frame->length - 2u;
        if (n > FM225_NAME_LEN) {
            n = FM225_NAME_LEN;
        }
        copy_text(reply->name, sizeof reply->name, &frame->data[2], n);
    } else if (reply->command == FM225_CMD_GET_STATUS && frame->length >= 3u) {
        reply->status = frame->data[2];
    } else if (reply->command == FM225_CMD_GET_ALL_IDS && frame->length >= 3u) {
        reply->face_count = frame->data[2];
    }
    return true;
}

bool fm225_decode_face_note(const fm225_frame_t *frame, fm225_face_note_t *note) {
    int16_t values[8];
    int i;
    if (frame->msg != FM225_MSG_NOTE || frame->length < 17u || frame->data[0] != FM225_NOTE_FACE) {
        return false;
    }
    for (i = 0; i < 8; i++) {
        size_t off = 1u + (size_t)i * 2u;
        values[i] = (int16_t)((uint16_t)frame->data[off] | ((uint16_t)frame->data[off + 1u] << 8));
    }
    note->status = values[0];
    note->left = values[1];
    note->top = values[2];
    note->right = values[3];
    note->bottom = values[4];
    note->yaw = values[5];
    note->pitch = values[6];
    note->roll = values[7];
    return true;
}

bool fm225_note_is_ready(const fm225_frame_t *frame) {
    return frame->msg == FM225_MSG_NOTE && frame->length >= 1u && frame->data[0] == FM225_NOTE_READY;
}

fm_verdict_t fm225_judge_verify(const fm225_frame_t *frame, uint16_t *slot_out, char *name_out,
                                size_t name_cap, uint8_t *code_out) {
    fm225_reply_t reply;
    if (slot_out != NULL) {
        *slot_out = 0u;
    }
    if (code_out != NULL) {
        *code_out = 0u;
    }
    if (name_out != NULL && name_cap > 0u) {
        name_out[0] = '\0';
    }
    if (frame->msg != FM225_MSG_REPLY) {
        return FM_VERDICT_IGNORE;
    }
    if (!fm225_decode_reply(frame, &reply)) {
        return FM_VERDICT_INVALID;
    }
    if (code_out != NULL) {
        *code_out = reply.result;
    }
    if (reply.command != FM225_CMD_VERIFY) {
        return FM_VERDICT_INVALID;
    }
    if (reply.result == FM225_ERR_REJECTED) {
        return FM_VERDICT_UNMATCHED;
    }
    if (reply.result != FM225_OK || !reply.has_id || frame->length < 4u + FM225_NAME_LEN ||
        reply.id > FM225_SLOT_MAX) {
        return FM_VERDICT_INVALID;
    }
    if (slot_out != NULL) {
        *slot_out = reply.id;
    }
    if (name_out != NULL && name_cap > 0u) {
        strncpy(name_out, reply.name, name_cap - 1u);
        name_out[name_cap - 1u] = '\0';
    }
    return FM_VERDICT_MATCH;
}

bool fm225_protocol_self_check(void) {
    static const uint8_t reset_cmd[] = {0xEFu, 0xAAu, 0x10u, 0x00u, 0x00u, 0x10u};
    static const uint8_t reset_reply[] = {0xEFu, 0xAAu, 0x00u, 0x00u, 0x02u, 0x10u, 0x00u, 0x12u};
    uint8_t built[8];
    fm225_parser_t parser;
    fm225_frame_t frame;
    fm225_reply_t reply;
    fm_parse_status_t status = FM_PARSE_NEED_MORE;
    size_t i;
    size_t n;

    n = fm225_build_reset(built, sizeof built);
    if (n != sizeof reset_cmd || memcmp(built, reset_cmd, sizeof reset_cmd) != 0) {
        return false;
    }
    fm225_parser_init(&parser);
    for (i = 0u; i < sizeof reset_reply; i++) {
        status = fm225_parse_byte(&parser, reset_reply[i], &frame);
    }
    if (status != FM_PARSE_FRAME) {
        return false;
    }
    if (!fm225_decode_reply(&frame, &reply)) {
        return false;
    }
    return reply.command == FM225_CMD_RESET && reply.result == FM225_OK;
}
