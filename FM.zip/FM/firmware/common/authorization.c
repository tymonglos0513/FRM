#include "authorization.h"

#include "data_lock.h"

#include <string.h>

static auth_user_t g_users[AUTH_CAPACITY];

static bool name_ok(const char *name) {
    size_t n = 0u;
    if (name == NULL || name[0] == '\0') {
        return false;
    }
    while (name[n] != '\0') {
        unsigned char c = (unsigned char)name[n];
        bool good = (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == ' ' ||
                    c == '_' || c == '-';
        if (!good || n >= 31u) {
            return false;
        }
        n++;
    }
    return true;
}

static bool schedule_ok(uint8_t days, uint16_t start_min, uint16_t end_min) {
    if (days == 0u || (days & ~0x7Fu) != 0u) {
        return false;
    }
    if (end_min > 1440u || start_min >= end_min) {
        return false;
    }
    return true;
}

static bool always_schedule(const auth_user_t *user) {
    return user->days == 0x7Fu && user->start_min == 0u && user->end_min == 1440u;
}

void auth_init(void) {
    data_lock();
    memset(g_users, 0, sizeof g_users);
    data_unlock();
}

bool auth_upsert(uint16_t slot, const char *name, bool enabled, uint8_t days, uint16_t start_min,
                 uint16_t end_min) {
    bool ok = false;
    data_lock();
    if (slot < AUTH_CAPACITY && name_ok(name) && schedule_ok(days, start_min, end_min)) {
        auth_user_t *user = &g_users[slot];
        memset(user, 0, sizeof(*user));
        user->used = true;
        user->enabled = enabled;
        user->days = days;
        user->slot = slot;
        user->start_min = start_min;
        user->end_min = end_min;
        strncpy(user->name, name, AUTH_NAME_LEN);
        user->name[AUTH_NAME_LEN] = '\0';
        ok = true;
    }
    data_unlock();
    return ok;
}

bool auth_allow_always(uint16_t slot, const char *name) {
    return auth_upsert(slot, name, true, 0x7Fu, 0u, 1440u);
}

bool auth_set_enabled(uint16_t slot, bool enabled) {
    bool ok = false;
    data_lock();
    if (slot < AUTH_CAPACITY && g_users[slot].used) {
        g_users[slot].enabled = enabled;
        ok = true;
    }
    data_unlock();
    return ok;
}

bool auth_remove(uint16_t slot) {
    bool ok = false;
    data_lock();
    if (slot < AUTH_CAPACITY && g_users[slot].used) {
        memset(&g_users[slot], 0, sizeof g_users[slot]);
        ok = true;
    }
    data_unlock();
    return ok;
}

auth_result_t auth_evaluate(uint16_t slot, bool time_known, uint8_t weekday, uint16_t minute_of_day) {
    auth_result_t result = AUTH_UNKNOWN_SLOT;
    data_lock();
    if (slot < AUTH_CAPACITY && g_users[slot].used) {
        const auth_user_t *user = &g_users[slot];
        if (!user->enabled) {
            result = AUTH_DISABLED;
        } else if (!time_known) {
            result = always_schedule(user) ? AUTH_GRANTED : AUTH_TIME_UNAVAILABLE;
        } else if (weekday > 6u || (user->days & (uint8_t)(1u << weekday)) == 0u || minute_of_day < user->start_min ||
                   minute_of_day >= user->end_min) {
            result = AUTH_OUTSIDE_SCHEDULE;
        } else {
            result = AUTH_GRANTED;
        }
    }
    data_unlock();
    return result;
}

bool auth_get(uint16_t slot, auth_user_t *out) {
    bool ok = false;
    data_lock();
    if (slot < AUTH_CAPACITY && g_users[slot].used) {
        *out = g_users[slot];
        ok = true;
    }
    data_unlock();
    return ok;
}

size_t auth_used_count(void) {
    size_t i;
    size_t n = 0u;
    data_lock();
    for (i = 0u; i < AUTH_CAPACITY; i++) {
        if (g_users[i].used) {
            n++;
        }
    }
    data_unlock();
    return n;
}

static void put_u16(uint8_t *p, uint16_t v) {
    p[0] = (uint8_t)(v & 0xFFu);
    p[1] = (uint8_t)(v >> 8);
}

static uint16_t get_u16(const uint8_t *p) {
    return (uint16_t)p[0] | (uint16_t)((uint16_t)p[1] << 8);
}

size_t auth_export_half(int half, uint8_t *dst, size_t cap) {
    int i;
    if (half != 0 && half != 1) {
        return 0u;
    }
    if (cap < AUTH_BLOB_SIZE) {
        return 0u;
    }
    data_lock();
    memset(dst, 0, AUTH_BLOB_SIZE);
    dst[0] = 'F';
    dst[1] = 'M';
    dst[2] = '0';
    dst[3] = '1';
    put_u16(&dst[4], (uint16_t)half);
    put_u16(&dst[6], AUTH_HALF);
    for (i = 0; i < AUTH_HALF; i++) {
        const auth_user_t *user = &g_users[(size_t)half * AUTH_HALF + (size_t)i];
        uint8_t *rec = &dst[8 + i * AUTH_REC_SIZE];
        rec[0] = user->used ? 1u : 0u;
        rec[1] = user->enabled ? 1u : 0u;
        rec[2] = user->days;
        put_u16(&rec[4], user->slot);
        put_u16(&rec[6], user->start_min);
        put_u16(&rec[8], user->end_min);
        memcpy(&rec[10], user->name, AUTH_NAME_LEN);
    }
    data_unlock();
    return AUTH_BLOB_SIZE;
}

bool auth_import_half(const uint8_t *src, size_t len) {
    int half;
    int i;
    auth_user_t imported[AUTH_HALF];
    if (src == NULL || len != AUTH_BLOB_SIZE) {
        return false;
    }
    data_lock();
    if (src[0] != 'F' || src[1] != 'M' || src[2] != '0' || src[3] != '1') {
        data_unlock();
        return false;
    }
    half = (int)get_u16(&src[4]);
    if ((half != 0 && half != 1) || get_u16(&src[6]) != AUTH_HALF) {
        data_unlock();
        return false;
    }
    memset(imported, 0, sizeof imported);
    for (i = 0; i < AUTH_HALF; i++) {
        const uint8_t *rec = &src[8 + i * AUTH_REC_SIZE];
        uint16_t slot;
        if (rec[0] == 0u) {
            continue;
        }
        slot = get_u16(&rec[4]);
        if (slot != (uint16_t)(half * AUTH_HALF + i)) {
            data_unlock();
            return false;
        }
        imported[i].used = true;
        imported[i].enabled = rec[1] != 0u;
        imported[i].days = rec[2];
        imported[i].slot = slot;
        imported[i].start_min = get_u16(&rec[6]);
        imported[i].end_min = get_u16(&rec[8]);
        memcpy(imported[i].name, &rec[10], AUTH_NAME_LEN);
        imported[i].name[AUTH_NAME_LEN] = '\0';
        if (!name_ok(imported[i].name) || !schedule_ok(imported[i].days, imported[i].start_min, imported[i].end_min)) {
            data_unlock();
            return false;
        }
    }
    memcpy(&g_users[(size_t)half * AUTH_HALF], imported, sizeof imported);
    data_unlock();
    return true;
}
