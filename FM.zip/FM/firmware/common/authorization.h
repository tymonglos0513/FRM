#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define AUTH_CAPACITY 100
#define AUTH_NAME_LEN 32
#define AUTH_HALF 50
#define AUTH_REC_SIZE 42
#define AUTH_BLOB_SIZE (8 + AUTH_HALF * AUTH_REC_SIZE)

typedef enum {
    AUTH_GRANTED = 0,
    AUTH_UNKNOWN_SLOT,
    AUTH_DISABLED,
    AUTH_OUTSIDE_SCHEDULE,
    AUTH_TIME_UNAVAILABLE
} auth_result_t;

typedef struct {
    bool used;
    bool enabled;
    uint8_t days; /* bit 0 = Sunday ... bit 6 = Saturday */
    uint16_t slot;
    uint16_t start_min;
    uint16_t end_min;
    char name[AUTH_NAME_LEN + 1];
} auth_user_t;

void auth_init(void);
bool auth_upsert(uint16_t slot, const char *name, bool enabled, uint8_t days, uint16_t start_min,
                 uint16_t end_min);
bool auth_allow_always(uint16_t slot, const char *name);
bool auth_set_enabled(uint16_t slot, bool enabled);
bool auth_remove(uint16_t slot);
auth_result_t auth_evaluate(uint16_t slot, bool time_known, uint8_t weekday, uint16_t minute_of_day);
bool auth_get(uint16_t slot, auth_user_t *out);
size_t auth_used_count(void);

size_t auth_export_half(int half, uint8_t *dst, size_t cap);
bool auth_import_half(const uint8_t *src, size_t len);
