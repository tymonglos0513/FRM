#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define EVENT_LOG_CAP 64
#define EVENT_REC_SIZE 16
#define EVENT_BLOB_SIZE (8 + EVENT_LOG_CAP * EVENT_REC_SIZE)

typedef enum {
    DOOR_EVT_BOOT = 1,
    DOOR_EVT_GRANTED = 2,
    DOOR_EVT_DENIED = 3,
    DOOR_EVT_UNMATCHED = 4,
    DOOR_EVT_EXIT = 5,
    DOOR_EVT_FORCED = 6,
    DOOR_EVT_HELD = 7,
    DOOR_EVT_TAMPER = 8,
    DOOR_EVT_LOCKOUT = 9,
    DOOR_EVT_ENROLL = 10,
    DOOR_EVT_REVOKE = 11,
    DOOR_EVT_DELETE = 12,
    DOOR_EVT_BROWNOUT = 13,
    DOOR_EVT_SCAN_TIMEOUT = 14,
    DOOR_EVT_STALE = 15,
    DOOR_EVT_FAULT = 16
} door_event_type_t;

typedef struct {
    uint32_t boot;
    uint32_t uptime_ms;
    uint16_t type;
    int16_t slot;
    uint16_t code;
} door_event_t;

void event_log_init(void);
void event_log_set_boot(uint32_t boot);
void event_log_add(uint16_t type, int16_t slot, uint16_t code, uint32_t uptime_ms);
size_t event_log_count(void);
bool event_log_newest(size_t index_from_newest, door_event_t *out);
const char *event_type_name(uint16_t type);

size_t event_log_export(uint8_t *dst, size_t cap);
bool event_log_import(const uint8_t *src, size_t len);
