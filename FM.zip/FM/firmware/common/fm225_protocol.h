#pragma once

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

/* HLK-FM225 UART framing, as exercised by the ESPHome hlk_fm22x component
 * and the public Hi-Link reset example (EF AA 10 00 00 10 -> EF AA 00 00 02 10 00 12).
 * A match from this parser is not an authorization decision. */

#define FM225_START_HI 0xEFu
#define FM225_START_LO 0xAAu
#define FM225_MAX_DATA 160u
#define FM225_NAME_LEN 32u

#define FM225_MSG_REPLY 0x00u
#define FM225_MSG_NOTE 0x01u

#define FM225_CMD_RESET 0x10u
#define FM225_CMD_GET_STATUS 0x11u
#define FM225_CMD_VERIFY 0x12u
#define FM225_CMD_ENROLL 0x13u
#define FM225_CMD_DELETE 0x20u
#define FM225_CMD_DELETE_ALL 0x21u
#define FM225_CMD_GET_ALL_IDS 0x24u
#define FM225_CMD_GET_VERSION 0x30u

#define FM225_NOTE_READY 0x00u
#define FM225_NOTE_FACE 0x01u

#define FM225_OK 0x00u
#define FM225_ERR_REJECTED 0x01u
#define FM225_ERR_ABORTED 0x02u
#define FM225_ERR_CAMERA 0x04u
#define FM225_ERR_UNKNOWN 0x05u
#define FM225_ERR_PARAM 0x06u
#define FM225_ERR_NO_MEMORY 0x07u
#define FM225_ERR_UNKNOWN_USER 0x08u
#define FM225_ERR_MAX_USER 0x09u
#define FM225_ERR_FACE_ENROLLED 0x0Au
#define FM225_ERR_LIVENESS 0x0Cu
#define FM225_ERR_TIMEOUT 0x0Du
#define FM225_ERR_AUTHORIZATION 0x0Eu

#define FM225_DIR_MIDDLE 0x01u
#define FM225_DIR_RIGHT 0x02u
#define FM225_DIR_LEFT 0x04u
#define FM225_DIR_DOWN 0x08u
#define FM225_DIR_UP 0x10u

#define FM225_SLOT_MAX 99u

typedef struct {
    uint8_t msg;
    uint16_t length;
    uint8_t data[FM225_MAX_DATA];
} fm225_frame_t;

typedef struct {
    uint8_t state;
    uint8_t msg;
    uint16_t length;
    uint16_t index;
    uint8_t checksum;
    uint8_t data[FM225_MAX_DATA];
    bool overflow;
} fm225_parser_t;

typedef enum {
    FM_PARSE_NEED_MORE = 0,
    FM_PARSE_FRAME,
    FM_PARSE_CHECKSUM,
    FM_PARSE_OVERSIZE
} fm_parse_status_t;

typedef enum {
    FM_VERDICT_MATCH = 0,
    FM_VERDICT_UNMATCHED,
    FM_VERDICT_INVALID,
    FM_VERDICT_IGNORE
} fm_verdict_t;

typedef struct {
    uint8_t command;
    uint8_t result;
    bool has_id;
    uint16_t id;
    uint8_t direction;
    uint8_t status;
    uint8_t face_count;
    char name[FM225_NAME_LEN + 1u];
} fm225_reply_t;

typedef struct {
    int16_t status;
    int16_t left;
    int16_t top;
    int16_t right;
    int16_t bottom;
    int16_t yaw;
    int16_t pitch;
    int16_t roll;
} fm225_face_note_t;

void fm225_parser_init(fm225_parser_t *parser);
fm_parse_status_t fm225_parse_byte(fm225_parser_t *parser, uint8_t byte, fm225_frame_t *out);

size_t fm225_build(uint8_t msg, const uint8_t *data, uint16_t length, uint8_t *out, size_t cap);
size_t fm225_build_reset(uint8_t *out, size_t cap);
size_t fm225_build_status(uint8_t *out, size_t cap);
size_t fm225_build_version(uint8_t *out, size_t cap);
size_t fm225_build_verify(uint8_t *out, size_t cap);
size_t fm225_build_enroll(const char *name, uint8_t direction, uint8_t timeout_s, uint8_t *out, size_t cap);
size_t fm225_build_delete(uint16_t slot, uint8_t *out, size_t cap);
size_t fm225_build_delete_all(uint8_t *out, size_t cap);

bool fm225_decode_reply(const fm225_frame_t *frame, fm225_reply_t *reply);
bool fm225_decode_face_note(const fm225_frame_t *frame, fm225_face_note_t *note);
bool fm225_note_is_ready(const fm225_frame_t *frame);

/* Host-verifiable decision for a VERIFY transaction. MATCH means the frame
 * claims a slot. It does not mean the slot is allowed to open the door. */
fm_verdict_t fm225_judge_verify(const fm225_frame_t *frame, uint16_t *slot_out, char *name_out,
                                size_t name_cap, uint8_t *code_out);

bool fm225_protocol_self_check(void);
