# Wiring and first power-up

The interface board distributes 12 V, makes 5 V for the ESP32-S3 DevKit, holds an adjustable rail for the FM225, and switches a 12 V strike relay. The FM225 (U1) and the DevKit (U2) stay off the board and connect through J1 and J2.

Mains stays inside the certified 12 V supply. Do not put mains on this board.

The interior mechanical exit must open the door with J4 unplugged. The exit button is only a convenience request.

## J2, DevKit end

| J2 pin | DevKit | Net |
| --- | --- | --- |
| 1 | GND | GND |
| 2 | 3V3 | V3V3, from the DevKit into this board |
| 3 | 5V | V5, into the DevKit, only with JP5 closed |
| 4 | GPIO17 | ESP TX to the module RX |
| 5 | GPIO18 | ESP RX from the module TX |
| 6 | GPIO4 | Lock, active high |
| 7 | GPIO5 | Door, low when the NC contact is closed |
| 8 | GPIO6 | Exit button, low when pressed |
| 9 | GPIO7 | Scan button, low when pressed |
| 10 | GPIO8 | Green LED |
| 11 | GPIO9 | Red LED |
| 12 | GPIO10 | Buzzer input |
| 13 | GPIO11 | Tamper, high when the NC switch is open |
| 14 | GPIO12 | Maintenance, low when the key switch is on |
| 15 | GPIO1 | 12 V sense, about 2.16 V at 12 V |
| 16 | GND | GND |

J1, looking at the published FM225 UART plug. Confirm this on the board before soldering:

| J1 pin | Module pin | Net |
| --- | --- | --- |
| 1 | GND | GND |
| 2 | UART RX | FM_RX, fed from GPIO17 |
| 3 | UART TX | FM_TX, read by GPIO18 |
| 4 | VCC | FM_VCC, after JP1 |

## Power-up order

Start with the FM225 unplugged, the strike unplugged, and JP1, JP2, JP3, JP4, JP5, and JP6 open. U3, U8, D2, and D4 are not fitted.

1. Current-limit a 12 V supply to about 1 A and connect it to J4, pin 1 positive.
2. LED3 should light. Measure V5_RAW at the JP5 pin that comes from U5. It must be 5.00 V ± 0.1 V before that jumper is ever closed.
3. Program the DevKit from USB while JP5 is open. Do not close JP5 and connect USB at the same time until you have checked that DevKit's power-path diode arrangement.
4. With JP1 open, measure TP1 and adjust U4. Stop here if you do not know the supply range for this exact FM225 revision. Manuals that say 5.5–9 V and the ESPHome note that says 5 V are not the same specification. Do not pick 7 V because it sits in the middle.
5. Fit F2 only after TP1 is at the voltage you have verified. TP3 must stay at 0 V while JP1 is open.
6. Close JP1 with the bench supply still current-limited. If the module current or temperature runs away, open JP1.
7. Measure J1 pin 3, the module TX pin, while it is idle. That voltage is the UART high level.
8. If that high level is about 3.3 V, leave U3 and U8 off, leave JP4 open, and fit JP2 and JP3.
9. If it is about 5 V, fit U3 and U8, put the JP4 shunt between VIO and 5 V, and leave JP2 and JP3 open.
10. If it is neither, stop. Do not connect GPIO17 or GPIO18, and do not connect VIO to the FM225 supply.
11. Only then cable J2 to the DevKit.
12. Put a lamp or a 100 ohm, 2 W resistor on J7 instead of the strike. Close JP6. Reset the DevKit, enter the download mode, and remove USB power. The load must stay dark through all of those. If it lights, stop and fix the driver before fitting a strike.
13. Fit D2 across the strike only when that strike's datasheet says an external diode is allowed. Cathode to strike positive.

## Lock driver

GPIO4 is pulled down by R1. A high level drives the PC817 LED. The phototransistor pulls the AO3400 gate up toward 3.3 V through R8. R9 holds the gate down. Q1 then sinks the 12 V relay coil. F3 feeds both the coil and the normally open contact, so a blown strike fuse also drops the coil. JP6 open means the coil cannot be energized at all.

```text
GPIO4 ---- R1 10k ---- GND
GPIO4 ---- R7 330 ---- PC817 LED ---- GND

3V3 ---- PC817 collector
PC817 emitter ---- R8 1k ---- gate ---- R9 100k ---- GND
                              gate ---- D5 5.1V ---- GND
                              gate ---- Q1

F3 ---- LOCK_12 ---- relay coil ---- JP6 ---- Q1 drain
                 \--- relay COM
                      relay NO ---- J7 strike+
                      J7 strike- ---- GND
D3 across the coil, cathode at LOCK_12
D2 across the strike, not fitted until the strike sheet allows it
```

Unpowered, and with GPIO4 floating, the strike gets no current. That matches a fail-secure strike only while the relay and MOSFET fail open. A shorted MOSFET or a welded contact can unlock the door, so this driver belongs on the protected interior side.

## Sensors

Each external contact is a switch to ground, then 1 k in series, then 10 k to 3.3 V and 100 nF to ground at the GPIO. Door, exit, tamper, and maintenance also have a PESD5V0 at the terminal.

For a bench with no switches, jumper J8 and J10 to ground so the firmware sees a closed door and a closed enclosure. Leave J11 open. S3 can be a local button from SCAN_IO to ground.

The buzzer module takes 5 V and ground from J13, and its input comes from GPIO10 through 1 k. Use a module with a logic input, not a bare piezo.

## Regenerating the drawing

`hardware/kicad/gen_schematic.py` writes `fm225-door.kicad_sch` and `hardware/netlist.csv`. Edit the script, then run it, if a connection changes. The drawing is a labeled netlist, not a finished PCB.
