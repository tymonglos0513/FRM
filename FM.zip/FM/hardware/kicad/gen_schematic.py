"""Generate the provisional FM225 interface schematic and its netlist."""

import collections
import uuid
from pathlib import Path

ROOT = "a0a0a0a0-a0a0-4a0a-8a0a-a0a0a0a0a0a0"
OUT = Path(__file__).resolve().parent


def uid():
    return str(uuid.uuid4())


def part(ref, value, nets, names, dnp=False):
    return {"ref": ref, "value": value, "nets": nets, "names": names, "dnp": dnp}


COLUMNS = [
    (
        "Power",
        [
            part("J4", "12V input", ["VIN", "GND"], ["+12V", "GND"]),
            part("F1", "3A", ["VIN", "V12"], ["1", "2"]),
            part("D1", "SMBJ15A", ["V12", "GND"], ["K", "A"]),
            part("C1", "470uF 25V", ["V12", "GND"], ["+", "-"]),
            part("C4", "100nF", ["V12", "GND"], ["1", "2"]),
            part("U5", "Pololu D24V22F5", ["V12", "GND", "V5_RAW", "V12"], ["VIN", "GND", "VOUT", "EN"]),
            part("JP5", "5V to ESP, shunt open", ["V5_RAW", "V5"], ["1", "2"]),
            part("R23", "2.2k", ["V5_RAW", "LED3_A"], ["1", "2"]),
            part("LED3", "Green 5V", ["LED3_A", "GND"], ["A", "K"]),
            part("C3", "100uF 10V", ["V5", "GND"], ["+", "-"]),
            part("C6", "100nF", ["V5", "GND"], ["1", "2"]),
            part("U4", "MP1584 module, set before use", ["V12", "GND", "VFM_RAW", "V12"], ["VIN", "GND", "VOUT", "EN"]),
            part("F2", "1.5A", ["VFM_RAW", "VFM"], ["1", "2"]),
            part("D4", "9.1V clamp DNP", ["VFM", "GND"], ["K", "A"], True),
            part("C2", "100uF 16V", ["VFM", "GND"], ["+", "-"]),
            part("C5", "100nF", ["VFM", "GND"], ["1", "2"]),
            part("JP1", "FM225 power, shunt open", ["VFM", "FM_VCC"], ["1", "2"]),
            part("TP1", "Measure VFM here", ["VFM"], ["1"]),
            part("TP3", "FM225 VCC", ["FM_VCC"], ["1"]),
        ],
    ),
    (
        "FM225 UART",
        [
            part("J1", "FM225 1.25mm", ["GND", "FM_RX", "FM_TX", "FM_VCC"], ["GND", "RX", "TX", "VCC"]),
            part("R16", "100", ["ESP_TX", "ESP_TX_A"], ["1", "2"]),
            part("U3", "74LVC1T45 TX DNP", ["V3V3", "GND", "ESP_TX_A", "FM_RX_B", "V3V3", "VIO"], ["VCCA", "GND", "A", "B", "DIR", "VCCB"], True),
            part("R17", "100", ["FM_RX_B", "FM_RX"], ["1", "2"]),
            part("JP2", "TX bypass DNP", ["ESP_TX", "FM_RX"], ["1", "2"], True),
            part("R18", "100", ["FM_TX", "FM_TX_B"], ["1", "2"]),
            part("U8", "74LVC1T45 RX DNP", ["V3V3", "GND", "ESP_RX_A", "FM_TX_B", "GND", "VIO"], ["VCCA", "GND", "A", "B", "DIR", "VCCB"], True),
            part("R19", "100", ["ESP_RX_A", "ESP_RX"], ["1", "2"]),
            part("JP3", "RX bypass DNP", ["FM_TX", "ESP_RX"], ["1", "2"], True),
            part("D7", "PESD5V0", ["ESP_RX", "GND"], ["1", "2"]),
            part("JP4", "VIO select, shunt open", ["V3V3", "VIO", "V5"], ["3V3", "VIO", "5V"]),
            part("TP2", "Measured VIO", ["VIO"], ["1"]),
            part("C14", "100nF", ["V3V3", "GND"], ["1", "2"]),
            part("C15", "100nF", ["VIO", "GND"], ["1", "2"]),
            part("C16", "100nF", ["V3V3", "GND"], ["1", "2"]),
            part("C17", "100nF", ["VIO", "GND"], ["1", "2"]),
            part(
                "J2",
                "ESP32-S3-DevKitC-1",
                [
                    "GND",
                    "V3V3",
                    "V5",
                    "ESP_TX",
                    "ESP_RX",
                    "LOCK_GPIO",
                    "DOOR_IO",
                    "EXIT_IO",
                    "SCAN_IO",
                    "LED_G",
                    "LED_R",
                    "BUZZ_IO",
                    "TAMPER_IO",
                    "MAINT_IO",
                    "SENSE",
                    "GND",
                ],
                [
                    "GND",
                    "3V3",
                    "5V",
                    "GPIO17",
                    "GPIO18",
                    "GPIO4",
                    "GPIO5",
                    "GPIO6",
                    "GPIO7",
                    "GPIO8",
                    "GPIO9",
                    "GPIO10",
                    "GPIO11",
                    "GPIO12",
                    "GPIO1",
                    "GND",
                ],
            ),
        ],
    ),
    (
        "Lock driver",
        [
            part("R1", "10k", ["LOCK_GPIO", "GND"], ["1", "2"]),
            part("R7", "330", ["LOCK_GPIO", "OPTO_A"], ["1", "2"]),
            part("U7", "PC817", ["OPTO_A", "GND", "OPTO_E", "V3V3"], ["A", "K", "E", "C"]),
            part("R8", "1k", ["OPTO_E", "LOCK_GATE"], ["1", "2"]),
            part("R9", "100k", ["LOCK_GATE", "GND"], ["1", "2"]),
            part("D5", "BZT52C5V1", ["LOCK_GATE", "GND"], ["K", "A"]),
            part("C7", "100nF", ["LOCK_GATE", "GND"], ["1", "2"]),
            part("Q1", "AO3400", ["LOCK_GATE", "GND", "DRAIN"], ["G", "S", "D"]),
            part("JP6", "Coil enable, shunt open", ["DRAIN", "COIL_N"], ["1", "2"]),
            part("F3", "2A provisional", ["V12", "LOCK_12"], ["1", "2"]),
            part("K1", "G5LE-1A-DC12", ["LOCK_12", "COIL_N", "LOCK_12", "STRIKE_P"], ["COIL+", "COIL-", "COM", "NO"]),
            part("D3", "1N4007", ["LOCK_12", "COIL_N"], ["K", "A"]),
            part("D2", "1N5408 DNP", ["STRIKE_P", "GND"], ["K", "A"], True),
            part("J7", "Strike", ["STRIKE_P", "GND"], ["+", "-"]),
        ],
    ),
    (
        "Inputs and indicators",
        [
            part("J8", "Door NC", ["J_DOOR", "GND"], ["SIG", "GND"]),
            part("R10", "1k", ["J_DOOR", "DOOR_IO"], ["1", "2"]),
            part("R4", "10k", ["DOOR_IO", "V3V3"], ["1", "2"]),
            part("C8", "100nF", ["DOOR_IO", "GND"], ["1", "2"]),
            part("D8", "PESD5V0", ["J_DOOR", "GND"], ["1", "2"]),
            part("J9", "Exit NO", ["J_EXIT", "GND"], ["SIG", "GND"]),
            part("R11", "1k", ["J_EXIT", "EXIT_IO"], ["1", "2"]),
            part("R5", "10k", ["EXIT_IO", "V3V3"], ["1", "2"]),
            part("C9", "100nF", ["EXIT_IO", "GND"], ["1", "2"]),
            part("D9", "PESD5V0", ["J_EXIT", "GND"], ["1", "2"]),
            part("S3", "Scan NO", ["SCAN_IO", "GND"], ["1", "2"]),
            part("R6", "10k", ["SCAN_IO", "V3V3"], ["1", "2"]),
            part("C10", "100nF", ["SCAN_IO", "GND"], ["1", "2"]),
            part("J10", "Tamper NC", ["J_TAMPER", "GND"], ["SIG", "GND"]),
            part("R12", "1k", ["J_TAMPER", "TAMPER_IO"], ["1", "2"]),
            part("R14", "10k", ["TAMPER_IO", "V3V3"], ["1", "2"]),
            part("C11", "100nF", ["TAMPER_IO", "GND"], ["1", "2"]),
            part("D10", "PESD5V0", ["J_TAMPER", "GND"], ["1", "2"]),
            part("J11", "Maintenance key", ["J_MAINT", "GND"], ["SIG", "GND"]),
            part("R13", "1k", ["J_MAINT", "MAINT_IO"], ["1", "2"]),
            part("R15", "10k", ["MAINT_IO", "V3V3"], ["1", "2"]),
            part("C12", "100nF", ["MAINT_IO", "GND"], ["1", "2"]),
            part("D11", "PESD5V0", ["J_MAINT", "GND"], ["1", "2"]),
            part("R2", "330", ["LED_G", "LED_G_A"], ["1", "2"]),
            part("LED1", "Green granted", ["LED_G_A", "GND"], ["A", "K"]),
            part("R3", "330", ["LED_R", "LED_R_A"], ["1", "2"]),
            part("LED2", "Red deny", ["LED_R_A", "GND"], ["A", "K"]),
            part("R20", "1k", ["BUZZ_IO", "BUZZ_SIG"], ["1", "2"]),
            part("J13", "Active buzzer", ["V5", "GND", "BUZZ_SIG"], ["VCC", "GND", "IN"]),
            part("R21", "100k", ["V12", "SENSE"], ["1", "2"]),
            part("R22", "22k", ["SENSE", "GND"], ["1", "2"]),
            part("C13", "100nF", ["SENSE", "GND"], ["1", "2"]),
            part("D6", "BZT52C3V3", ["SENSE", "GND"], ["K", "A"]),
        ],
    ),
]


def symbol_id(pin_count):
    return f"door:P{pin_count}"


def library_symbols():
    counts = set()
    for _title, parts in COLUMNS:
        for item in parts:
            counts.add(len(item["nets"]))
    chunks = []
    for count in sorted(counts):
        pins = []
        half = (count - 1) / 2.0
        for index in range(count):
            y = (half - index) * 2.54
            pins.append(
                "\n".join(
                    [
                        "        (pin passive line",
                        f"          (at -12.7 {y:.2f} 180)",
                        "          (length 2.54)",
                        '          (name "~"',
                        "            (effects (font (size 1.27 1.27))))",
                        f'          (number "{index + 1}"',
                        "            (effects (font (size 1.27 1.27))))",
                        "        )",
                    ]
                )
            )
        body_top = half * 2.54 + 2.54
        body_bot = -body_top
        chunks.append(
            "\n".join(
                [
                    f'    (symbol "{symbol_id(count)}"',
                    "      (pin_names (offset 0.254) hide)",
                    "      (exclude_from_sim no)",
                    "      (in_bom yes)",
                    "      (on_board yes)",
                    '      (property "Reference" "U"',
                    "        (at 0 0 0)",
                    "        (effects (font (size 1.27 1.27))))",
                    '      (property "Value" "P"',
                    "        (at 0 -2.54 0)",
                    "        (effects (font (size 1.27 1.27))))",
                    '      (property "Footprint" ""',
                    "        (at 0 0 0)",
                    "        (effects (font (size 1.27 1.27)) hide))",
                    '      (property "Datasheet" ""',
                    "        (at 0 0 0)",
                    "        (effects (font (size 1.27 1.27)) hide))",
                    '      (symbol "P_0_1"',
                    f"        (rectangle (start -7.62 {body_bot:.2f}) (end 10.16 {body_top:.2f})",
                    "          (stroke (width 0.254) (type default))",
                    "          (fill (type background)))",
                    "      )",
                    '      (symbol "P_1_1"',
                    *pins,
                    "      )",
                    "    )",
                ]
            )
        )
    return "\n".join(chunks)


def place_parts():
    placed = []
    texts = []
    x_positions = [90.0, 360.0, 630.0, 900.0]
    for column, (title, parts) in enumerate(COLUMNS):
        x = x_positions[column]
        y = 28.0
        texts.append((title, x, 12.0, 2.0))
        for item in parts:
            count = len(item["nets"])
            placed.append((item, x, y))
            y += max(16.0, count * 2.54 + 10.0)
    return placed, texts


def emit():
    placed, texts = place_parts()
    nets = collections.defaultdict(list)
    symbols = []
    wires = []
    labels = []
    for item, x, y in placed:
        count = len(item["nets"])
        half = (count - 1) / 2.0
        pin_uuids = []
        for index, (net, name) in enumerate(zip(item["nets"], item["names"])):
            pin_y = y + (half - index) * 2.54
            pin_x = x - 12.7
            stub_x = pin_x - 7.62
            wire_uuid = uid()
            wires.append(
                f'  (wire (pts (xy {pin_x:.2f} {pin_y:.2f}) (xy {stub_x:.2f} {pin_y:.2f})) '
                f'(stroke (width 0) (type default)) (uuid "{wire_uuid}"))'
            )
            labels.append(
                "\n".join(
                    [
                        f'  (global_label "{net}"',
                        "    (shape bidirectional)",
                        f"    (at {stub_x:.2f} {pin_y:.2f} 180)",
                        "    (fields_autoplaced yes)",
                        "    (effects (font (size 1.27 1.27)) (justify right))",
                        f'    (uuid "{uid()}")',
                        '    (property "Intersheetrefs" "${INTERSHEET_REFS}"',
                        f"      (at {stub_x - 2.54:.2f} {pin_y:.2f} 0)",
                        "      (effects (font (size 1.27 1.27)) (justify right) hide))",
                        "  )",
                    ]
                )
            )
            pin_uuids.append(uid())
            nets[net].append(f"{item['ref']}.{index + 1} {name}")
        dnp = "yes" if item["dnp"] else "no"
        pin_lines = "\n".join(
            f'    (pin "{index + 1}" (uuid "{pin_uuid}"))' for index, pin_uuid in enumerate(pin_uuids)
        )
        symbols.append(
            "\n".join(
                [
                    "  (symbol",
                    f'    (lib_id "{symbol_id(count)}")',
                    f"    (at {x:.2f} {y:.2f} 0)",
                    "    (unit 1)",
                    "    (exclude_from_sim no)",
                    "    (in_bom yes)",
                    "    (on_board yes)",
                    f"    (dnp {dnp})",
                    f'    (uuid "{uid()}")',
                    f'    (property "Reference" "{item["ref"]}"',
                    f"      (at {x + 12.7:.2f} {y - 1.5:.2f} 0)",
                    "      (effects (font (size 1.27 1.27)) (justify left)))",
                    f'    (property "Value" "{item["value"]}"',
                    f"      (at {x + 12.7:.2f} {y + 1.5:.2f} 0)",
                    "      (effects (font (size 1.27 1.27)) (justify left)))",
                    '    (property "Footprint" ""',
                    f"      (at {x:.2f} {y:.2f} 0)",
                    "      (effects (font (size 1.27 1.27)) hide))",
                    '    (property "Datasheet" ""',
                    f"      (at {x:.2f} {y:.2f} 0)",
                    "      (effects (font (size 1.27 1.27)) hide))",
                    pin_lines,
                    "    (instances",
                    '      (project "fm225-door"',
                    f'        (path "/{ROOT}"',
                    f'          (reference "{item["ref"]}")',
                    "          (unit 1)",
                    "        )",
                    "      )",
                    "    )",
                    "  )",
                ]
            )
        )
    note_lines = [
        "Provisional interface. Do not apply power to the FM225 until its supply and UART high level are measured.",
        "Leave JP1, JP4, JP5 and JP6 open. Do not fit JP2, JP3, U3, U8, D2 or D4 until the bring-up procedure says so.",
        "U1 FM225 and U2 ESP32-S3-DevKitC-1-N8R8 stay off this board and mate through J1 and J2.",
        "U6 is a supervised 12V supply or access-control UPS feeding J4. Do not connect a bare lithium cell.",
        "Mechanical egress must work with this board unplugged. This is not a certified access-control panel.",
    ]
    for index, text in enumerate(note_lines):
        texts.append((text, 90.0, 760.0 + index * 6.0, 1.27))
    text_sexpr = []
    for text, x, y, size in texts:
        text_sexpr.append(
            "\n".join(
                [
                    f'  (text "{text}"',
                    f"    (at {x:.2f} {y:.2f} 0)",
                    f"    (effects (font (size {size:.2f} {size:.2f})))",
                    f'    (uuid "{uid()}")',
                    "  )",
                ]
            )
        )
    sch = "\n".join(
        [
            "(kicad_sch",
            "  (version 20231120)",
            '  (generator "eeschema")',
            '  (generator_version "8.0.4")',
            f'  (uuid "{ROOT}")',
            '  (paper "A0")',
            "  (title_block",
            '    (title "FM225 door interface, provisional")',
            '    (date "2026-10-27")',
            '    (rev "0.1")',
            '    (comment 1 "Measure FM225 VCC and UART level before closing JP1 or JP4")',
            '    (comment 2 "Fail-secure strike. Mechanical exit must not depend on this board")',
            '    (comment 3 "No PCB layout yet. Netlist schematic for review and perfboard wiring")',
            "  )",
            "  (lib_symbols",
            library_symbols(),
            "  )",
            *text_sexpr,
            *symbols,
            *wires,
            *labels,
            "  (sheet_instances",
            '    (path "/"',
            '      (page "1")',
            "    )",
            "  )",
            ")",
            "",
        ]
    )
    sch_path = OUT / "fm225-door.kicad_sch"
    sch_path.write_text(sch, encoding="utf-8")
    balance = 0
    for char in sch:
        if char == "(":
            balance += 1
        elif char == ")":
            balance -= 1
            if balance < 0:
                raise SystemExit("unbalanced schematic")
    if balance != 0:
        raise SystemExit(f"unbalanced schematic: {balance}")
    lonely = [name for name, pins in nets.items() if len(pins) < 2]
    if lonely:
        raise SystemExit("nets with fewer than two pins: " + ", ".join(lonely))
    rows = ["ref,pin,name,net"]
    for net in sorted(nets):
        for pin in nets[net]:
            ref_pin, name = pin.split(" ", 1)
            ref, number = ref_pin.split(".")
            rows.append(f"{ref},{number},{name},{net}")
    net_path = OUT.parent / "netlist.csv"
    net_path.write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(f"wrote {sch_path}")
    print(f"wrote {net_path}")
    print(f"{len(placed)} parts, {len(nets)} nets")


if __name__ == "__main__":
    emit()
