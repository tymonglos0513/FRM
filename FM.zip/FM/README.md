# FM225 door controller

One-door controller for a Hi-Link HLK-FM225 face module and an ESP32-S3. The module matches a face locally. The ESP32 decides whether that slot may open the door, pulses a 12 V fail-secure strike, and watches the door contact.

This is a bench design. It is not a certified access-control panel, and it is not a fire-egress device. The mechanical exit on the inside of the door has to work with this board unplugged.

## What is in the tree

| Path | What it is |
| --- | --- |
| `hardware/kicad/fm225-door.kicad_sch` | Provisional KiCad 8 schematic. Open this in KiCad. |
| `hardware/kicad/gen_schematic.py` | Source for that schematic and for `hardware/netlist.csv`. |
| `hardware/BOM.csv` | Parts list, including what stays unpopulated on first power-up. |
| `hardware/WIRING.md` | Perfboard wiring, connector map, and the power-up order. |
| `firmware/esphome/fm225-door-prototype.yaml` | USB-only bench firmware. No Wi-Fi and no enrollment. |
| `firmware/esp-idf/` | Production-shaped firmware: allow-list, 5 s pulse, exit, tamper, log. |
| `firmware/common/` | Protocol, authorization, and door state machine. |
| `firmware/test/test_main.c` | Host checks for those three. |
| `docs/SECURITY.md` | Controls that have to stay true before a real door. |
| `docs/TEST_PLAN.md` | What to measure on the bench and on the door. |

There is no PCB layout. Connector orientation, the FM225 supply, and the strike suppressor cannot be frozen until the revision datasheet and the strike sheet are in hand.

## How a grant happens

1. The scan button, or the console `scan` command, asks the FM225 to verify.
2. A match is accepted only while that request is still inside its 8 s window.
3. The slot must exist in the local allow-list and be enabled. A face stored in the module is not enough.
4. GPIO4 then goes high for 5 s. A separate task forces it low if it stays high for more than 10 s.
5. Opening the door during that pulse, or during the following 10 s, is an authorized open. Opening it otherwise is a forced-open alarm.
6. The interior exit button uses the same 5 s pulse. It does not consult the camera.
7. Five unmatched or rejected scans in 60 s pause face scans for 30 s. The exit button still works.
8. Enrollment, revoke, and delete require the keyed maintenance switch and a closed tamper switch. They are console commands, not door buttons.

No realtime clock is fitted, so a schedule other than "always" fails closed. `allow` writes an always-valid record. Revoking a user does not require deleting the template in the module.

## Electrical points that are still open

Published FM225 guides disagree. Seller manuals say 5.5–9 V. The ESPHome integration guide says the module can be powered from 5 V. Neither source states the UART high level. The schematic therefore leaves JP1, JP4, JP5, and JP6 open, and it does not install the level translators or the bypass jumpers. `hardware/WIRING.md` is the order to close them.

The 12 V strike relay is active-high. GPIO4 has a pulldown, the relay contact is normally open, and the coil jumper JP6 is open until an off-at-boot test passes.

## Build

Host checks, from the repository root, with any C11 compiler:

```text
gcc -std=c11 -Wall -Wextra -Werror -I firmware/common ^
  firmware/common/fm225_protocol.c firmware/common/authorization.c ^
  firmware/common/access_sm.c firmware/common/debounce.c ^
  firmware/common/event_log.c firmware/common/door_logic.c ^
  firmware/common/data_lock.c firmware/test/test_main.c ^
  -o firmware/test/test_fm225.exe
firmware\test\test_fm225.exe
```

This machine had no C compiler, so those checks have not been executed here.

ESP-IDF 5.x, from `firmware/esp-idf`, for the N8R8 module:

```text
idf.py set-target esp32s3
idf.py build
idf.py -p COMx flash monitor
```

Program over USB with JP5 open. The console is the USB serial/JTAG port. Commands are listed by `help`. Nothing is authorized until `allow` is used with the maintenance key on.

ESPHome bench image:

```text
esphome run firmware/esphome/fm225-door-prototype.yaml
```

That image accepts only face slot 0, and only after a scan request, while the tamper input reads closed. Do not put a strike on it until the dummy-load test in `hardware/WIRING.md` passes.

## Bench jumpers

An unwired door contact looks open, so face scan stays disabled and a held-open alarm starts after 30 s. An unwired tamper switch looks open and blocks face unlock. For a bare DevKit, jumper J8 and J10 to ground. Leave the maintenance input open until you intend to enroll.
