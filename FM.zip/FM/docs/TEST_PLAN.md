# Verification

## Already covered by `firmware/test/test_main.c`

These run on a PC, without the module:

- The published reset frame `EF AA 10 00 00 10` and its reply `EF AA 00 00 02 10 00 12`.
- A verify match, a reject, a liveness failure, a wrong command echo, and a slot above 99.
- An unknown or revoked slot does not become a grant. Slot 0 is not special.
- A match outside an open scan, or after the scan deadline, does not energize the lock.
- Five rejects lock out face scans. The exit button still pulses the lock.
- A door that opens with no grant is forced-open. A door that opens during the grant window is not.
- A door held past 30 s raises the held-open flag.
- Tamper and a failed 12 V reading block face grants and do not block the exit pulse.
- Enrollment is refused unless maintenance is on and tamper is closed.

No C compiler was available in this workspace, so that file has not been executed here. The command is in the root `README.md`.

## Still required on the bench

1. Measure the FM225 supply range and the idle UART high level before closing JP1 or JP4.
2. Measure startup current and the buck ripple at the chosen voltage.
3. Confirm GPIO4 and J7 stay off through reset, download mode, and a power cycle, using a lamp rather than the strike.
4. Enroll one person through the maintenance console, in the order center, right, left, down, up. Confirm `allow` is still required before the door grants.
5. Confirm an enrolled but revoked slot is denied, and an unknown face is denied.
6. Confirm the exit button pulses the relay with the camera unplugged.
7. Open the door contact without a grant and confirm the forced-open indication. Hold it and confirm the held-open indication.
8. Open the tamper input and confirm face scan stops and the exit button still works.
9. Drop the 12 V rail after it has been seen good, and confirm new face grants stop. Restore it and confirm they return.

## Still required before an occupied door

- Photo, screen, and mask trials against this module and this lighting.
- Strike timing with the real door, and a check that the interior mechanical exit works with the controller powerless.
- Mains loss, including whatever supervised supply was chosen for U6.
- A decision on fire-egress hardware if the opening is an escape route. Fail-secure is not automatically acceptable there.
- Firmware update authentication if the production image will be updated in the field.

The ESP-IDF and ESPHome images in this tree have not been flashed.
