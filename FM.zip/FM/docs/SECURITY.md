# Security boundaries

The FM225 UART frame has a checksum, not a signature. Anyone who can reach those wires can send a frame that looks like a match. The wiring stays inside the enclosure, the enclosure has a tamper switch, and the lock driver is on the interior side. That is containment, not cryptographic authentication. A high-security door needs a second factor.

What the firmware already enforces:

- A match unlocks only as the answer to a scan this controller just started, and only before the 8 s deadline.
- The slot must be present and enabled in the controller's own table. Deleting that record locks the person out even if the template is still in the module.
- The scan button cannot enroll, delete, or revoke. Those commands need the maintenance key and a closed tamper switch.
- There is no network unlock path. Wi-Fi is not started, and the ESPHome bench image has no API.
- The lock output is normally open, pulled down, and cut off by a second task after 10 s.
- Exit is an edge, so a stuck button is one 5 s pulse rather than a held unlock.
- The allow-list and the event log are guarded by a recursive lock so the console and the recognition task cannot tear a record.

What this revision does not do:

- It does not prove the FM225 liveness check against photos, screens, or masks. That is a test in `docs/TEST_PLAN.md`, not a claim.
- It does not supervise the door contact against a cut or shorted wire. A production input needs end-of-line resistors.
- It does not encrypt flash or turn on secure boot. Those belong in a production `sdkconfig` after the usual key procedure, not in a first flash of a dev board.
- It does not provide the mechanical egress. That hardware has to work with no power.

For an installation in the EU, face templates are biometric data. This repository does not choose the legal basis, the retention period, or the notice. Get that review before enrolling employees or the public.

A recognized face is not, by itself, authorization. The local table is.
